import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';

type CartItem = {
  id: string;
  name: string;
  price: string;
  quantity: number;
  size?: string;
  image?: string;
};

type CartState = {
  items: CartItem[];
  total: number;
  isOpen: boolean;
};

type CartAction =
  | { type: 'ADD_ITEM'; payload: CartItem }
  | { type: 'REMOVE_ITEM'; payload: string }
  | { type: 'UPDATE_QUANTITY'; payload: { id: string; quantity: number } }
  | { type: 'TOGGLE_CART' }
  | { type: 'CLEAR_CART' };

const CartContext = createContext<{
  state: CartState;
  dispatch: React.Dispatch<CartAction>;
} | null>(null);

// Load cart state from localStorage
const loadCartState = (): CartState => {
  try {
    const savedState = localStorage.getItem('cartState');
    if (savedState) {
      return JSON.parse(savedState);
    }
  } catch (error) {
    console.error('Error loading cart state:', error);
  }
  return {
    items: [],
    total: 0,
    isOpen: false,
  };
};

const cartReducer = (state: CartState, action: CartAction): CartState => {
  let newState: CartState;
  
  switch (action.type) {
    case 'ADD_ITEM': {
      const existingItemIndex = state.items.findIndex(
        item => item.id === action.payload.id
      );

      if (existingItemIndex !== -1) {
        // If item exists, increment quantity
        const updatedItems = [...state.items];
        updatedItems[existingItemIndex] = {
          ...updatedItems[existingItemIndex],
          quantity: updatedItems[existingItemIndex].quantity + 1
        };
        newState = {
          ...state,
          items: updatedItems,
          isOpen: true
        };
      } else {
        // If item doesn't exist, add it with quantity 1
        newState = {
          ...state,
          items: [...state.items, { ...action.payload, quantity: 1 }],
          isOpen: true
        };
      }
      break;
    }
    case 'REMOVE_ITEM':
      newState = {
        ...state,
        items: state.items.filter(item => item.id !== action.payload)
      };
      break;
    case 'UPDATE_QUANTITY': {
      const { id, quantity } = action.payload;
      if (quantity === 0) {
        newState = {
          ...state,
          items: state.items.filter(item => item.id !== id)
        };
      } else {
        newState = {
          ...state,
          items: state.items.map(item =>
            item.id === id ? { ...item, quantity } : item
          )
        };
      }
      break;
    }
    case 'TOGGLE_CART':
      newState = {
        ...state,
        isOpen: !state.isOpen
      };
      break;
    case 'CLEAR_CART':
      newState = {
        ...state,
        items: [],
        isOpen: false
      };
      break;
    default:
      return state;
  }

  // Calculate total based on item prices and quantities
  const total = newState.items.reduce((sum, item) => {
    const price = parseFloat(item.price.replace(' zł', ''));
    return sum + (price * item.quantity);
  }, 0);

  newState.total = total;

  // Save to localStorage after each update
  localStorage.setItem('cartState', JSON.stringify(newState));
  return newState;
};

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(cartReducer, null, loadCartState);

  return (
    <CartContext.Provider value={{ state, dispatch }}>
      {children}
      <Cart />
    </CartContext.Provider>
  );
};

const Cart: React.FC = () => {
  const context = useContext(CartContext);
  const navigate = useNavigate();
  
  if (!context) throw new Error('Cart must be used within CartProvider');
  const { state, dispatch } = context;

  const handleCheckout = () => {
    dispatch({ type: 'TOGGLE_CART' }); // Close the cart
    navigate('/order'); // Navigate to order page
  };

  return (
    <AnimatePresence>
      {state.isOpen && (
        <>
          {/* Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.5 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black z-40"
            onClick={() => dispatch({ type: 'TOGGLE_CART' })}
          />
          
          {/* Cart Panel */}
          <motion.div
            initial={{ opacity: 0, x: 300 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 300 }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="fixed right-0 top-0 h-full w-96 bg-white shadow-xl z-50"
          >
            <div className="p-4 h-full flex flex-col">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold">Your Cart</h2>
                <button
                  onClick={() => dispatch({ type: 'TOGGLE_CART' })}
                  className="text-gray-500 hover:text-gray-700 text-2xl"
                >
                  ×
                </button>
              </div>
              
              <div className="flex-grow overflow-auto">
                {state.items.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    Your cart is empty
                  </div>
                ) : (
                  state.items.map((item) => (
                    <motion.div
                      key={item.id}
                      layout
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      className="flex items-center gap-4 p-4 border-b"
                    >
                      {item.image && (
                        <img
                          src={item.image}
                          alt={item.name}
                          className="w-16 h-16 object-cover rounded"
                        />
                      )}
                      <div className="flex-grow">
                        <h3 className="font-semibold">{item.name}</h3>
                        {item.size && (
                          <p className="text-sm text-gray-500 capitalize">
                            Size: {item.size}
                          </p>
                        )}
                        <p className="text-red-600">{item.price}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() =>
                            dispatch({
                              type: 'UPDATE_QUANTITY',
                              payload: { id: item.id, quantity: Math.max(0, item.quantity - 1) }
                            })
                          }
                          className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center"
                        >
                          -
                        </button>
                        <span className="w-8 text-center">{item.quantity}</span>
                        <button
                          onClick={() =>
                            dispatch({
                              type: 'UPDATE_QUANTITY',
                              payload: { id: item.id, quantity: item.quantity + 1 }
                            })
                          }
                          className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center"
                        >
                          +
                        </button>
                      </div>
                    </motion.div>
                  ))
                )}
              </div>
              
              <div className="border-t pt-4 mt-auto">
                <div className="flex justify-between items-center mb-4">
                  <span className="text-lg font-semibold">Total:</span>
                  <span className="text-xl font-bold">{state.total.toFixed(2)} zł</span>
                </div>
                <button
                  onClick={handleCheckout}
                  className="w-full bg-red-600 text-white py-3 rounded-md hover:bg-red-700 transition-colors"
                >
                  Proceed to Checkout
                </button>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within CartProvider');
  }
  return context;
};