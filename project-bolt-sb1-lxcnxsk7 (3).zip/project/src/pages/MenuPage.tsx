import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { motion, AnimatePresence } from 'framer-motion';
import { useCart } from '../context/CartContext';
import { ShoppingBag } from 'lucide-react';

const MenuPage = () => {
  const { t } = useTranslation();
  const [activeMenu, setActiveMenu] = useState('pizza');
  const { dispatch } = useCart();

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { 
      opacity: 0,
      y: 20
    },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5,
        ease: "easeOut"
      }
    }
  };

  const handleAddToCart = (item: any, size?: string) => {
    const price = Array.isArray(item.prices) 
      ? item.prices[size ? ['small', 'medium', 'large', 'mega'].indexOf(size) : 0]
      : item.price;

    const formattedPrice = price.includes('zł') ? price : `${price} zł`;

    const itemToAdd = {
      id: `${item.name}${size ? `-${size}` : ''}`,
      name: item.name,
      price: formattedPrice,
      quantity: 1,
      size,
      image: item.image,
    };

    dispatch({
      type: 'ADD_ITEM',
      payload: itemToAdd,
    });
  };

  const menuData = {
    pizza: {
      title: 'Pizza Menu',
      items: [
        {
          name: 'MARGHERITA',
          description: 'sos pomidorowy, mozzarella',
          price: '30 zł',
          image: 'https://images.unsplash.com/photo-1574071318508-1cdbab80d002?auto=format&fit=crop&q=80&w=800'
        },
        {
          name: 'FUNGI',
          description: 'Sos pomidorowy, mozzarella, pieczarki',
          price: '32 zł',
          image: 'https://images.unsplash.com/photo-1628840042765-356cda07504e?auto=format&fit=crop&q=80&w=800'
        },
        {
          name: 'SALAMI',
          description: 'sos pomidorowy, mozzarella, salami',
          price: '33 zł',
          image: 'https://images.unsplash.com/photo-1458642849426-cfb724f15ef7?auto=format&fit=crop&q=80&w=800'
        },
        {
          name: 'PROSCIUTTO',
          description: 'Sos pomidorowy, mozzarella, szynka',
          price: '33 zł',
          image: 'https://images.unsplash.com/photo-1604068549290-dea0e4a305ca?auto=format&fit=crop&q=80&w=800'
        },
        {
          name: 'PROSCIUTTO FUNGI',
          description: 'Sos pomidorowy, mozzarella, szynka, pieczarki',
          price: '35 zł',
          image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800'
        },
        {
          name: 'DIAVOLA',
          description: 'Sos pomidorowy, mozzarella, pieczarki, salami, jalapeno, peperoni',
          price: '45 zł',
          image: 'https://images.unsplash.com/photo-1458642849426-cfb724f15ef7?auto=format&fit=crop&q=80&w=800'
        },
        {
          name: 'CIAO CAPPERI',
          description: 'Sos pomidorowy, mozzarella, pieczarki, oliwki, salami, cebula, kapary',
          price: '30 zł',
          image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800'
        },
        {
          name: 'HAWAII',
          description: 'Sos pomidorowy, mozzarella, szynka, ananas',
          price: '36 zł',
          image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&q=80&w=800'
        },
        {
          name: 'TONNO',
          description: 'Sos pomidorowy, mozzarella, tuńczyk, kapary, cebula, oliwki',
          price: '30 zł',
          image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800'
        },
        {
          name: 'CARBONARA',
          description: 'Sos śmietanowy, mozzarella, boczek, jajko, ser brie, cebula, grana padano',
          price: '30 zł',
          image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800'
        },
        {
          name: 'CIAO ITALIA',
          description: 'Sos, mozzarella, szynka parmeńska, rukola, cherry pomidory',
          price: '44 zł',
          image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800'
        },
        {
          name: 'QUATRO FORMAGGI',
          description: 'Mozzarella, ser brie, gorgonzola, grana padano',
          price: '40 zł',
          image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800'
        },
        {
          name: 'CHORIZO',
          description: 'Sos pomidorowy, mozzarella, cebula, jalapeno, chorizo, oliwki',
          price: '35 zł',
          image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800'
        },
        {
          name: 'CARNE',
          description: 'Sos śmietanowy, mozzarella, boczek, szynka, salami, cebula',
          price: '41 zł',
          image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800'
        },
        {
          name: 'MIELE',
          description: 'Sos pomidorowy, mozzarella, chorizo, jalapeno, rukola, miód',
          price: '45 zł',
          image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800'
        },
        {
          name: 'CALZONE',
          description: 'Sos pomidorowy, mozzarella, szynka, salami, pieczarki',
          price: '35 zł',
          image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800'
        },
        {
          name: 'KEBAB PIZZA',
          description: 'Sos pomidorowy, mozzarella, kebab wołowina, peperoni, cebula, cherry pomidory',
          price: '45 zł',
          image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800'
        },
        {
          name: 'BAMBINO',
          description: 'Sos pomidorowy, mozzarella',
          price: '25 zł',
          image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800'
        },
        {
          name: 'BELLA',
          description: 'Sos pomidorowy, mozzarella, oliwki, szynka, grana padano',
          price: '39 zł',
          image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800'
        },
        {
          name: 'CALZONE VEGETARIANA',
          description: 'Sos pomidorowy, mozzarella, pieczarki, cebula, kukurydza, oliwki',
          price: '33 zł',
          image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800'
        },
        {
          name: 'VEGETARIANA',
          description: 'Sos pomidorowy, mozzarella, oliwki, cebula, pieczarki, kukurydza, rukola',
          price: '33 zł',
          image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800'
        }
      ]
    },
    kebab: {
      categories: [
        {
          title: 'CIASTO',
          subtitle: 'mały / średni / duży / mega',
          items: [
            {
              name: 'KEBAB W CIEŚCIE',
              description: 'mięso, surówki, sos',
              prices: ['22 zł', '26 zł', '31 zł', '36 zł'],
              image: 'https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?auto=format&fit=crop&q=80&w=800'
            },
            {
              name: 'CIASTO Z SEREM',
              description: 'mięso, surówki, ser żółty, sos',
              prices: ['24 zł', '28 zł', '33 zł', '38 zł'],
              image: 'https://images.unsplash.com/photo-1542574271-7f3b92e6c821?auto=format&fit=crop&q=80&w=800'
            },
            {
              name: 'CIASTO Z FRYTKAMI',
              description: 'mięso, frytki, sos',
              prices: ['25 zł', '29 zł', '35 zł', '39 zł'],
              image: 'https://images.unsplash.com/photo-1529006557810-274b9b2fc783?auto=format&fit=crop&q=80&w=800'
            },
            {
              name: 'CIASTO SAMO MIĘSO',
              description: 'mięso, sos',
              prices: ['27 zł', '29 zł', '32 zł', '45 zł'],
              image: 'https://images.unsplash.com/photo-1561626423-a51b45dc0e65?auto=format&fit=crop&q=80&w=800'
            },
            {
              name: 'POLĘDWICZKI W CIEŚCIE',
              description: 'tortilla, polędwiczki, surówki, sos',
              prices: ['22 zł', '26 zł', '31 zł', '36 zł'],
              image: 'https://images.unsplash.com/photo-1550507992-eb63ffee0847?auto=format&fit=crop&q=80&w=800'
            },
            {
              name: 'POLĘDWICZKI I FRYTKI',
              description: 'tortilla, polędwiczki, frytki, surówki, sos',
              prices: ['25 zł', '29 zł', '35 zł', '39 zł'],
              image: 'https://images.unsplash.com/photo-1593001874117-c99c900c6c0e?auto=format&fit=crop&q=80&w=800'
            },
            {
              name: 'POLĘDWICZKI Z SEREM',
              description: 'tortilla, polędwiczki, surówki, ser żółty, sos',
              prices: ['24 zł', '28 zł', '33 zł', '38 zł'],
              image: 'https://images.unsplash.com/photo-1542574271-7f3b92e6c821?auto=format&fit=crop&q=80&w=800'
            }
          ]
        },
        {
          title: 'BUŁKA',
          subtitle: 'standard / mega',
          items: [
            {
              name: 'KEBAB BUŁKA',
              description: 'mięso, surówki, sos',
              prices: ['23 zł', '33 zł'],
              image: 'https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?auto=format&fit=crop&q=80&w=800'
            },
            {
              name: 'BUŁKA Z FRYTKAMI',
              description: 'mięso, frytki, sos',
              prices: ['26 zł', '36 zł'],
              image: 'https://images.unsplash.com/photo-1529006557810-274b9b2fc783?auto=format&fit=crop&q=80&w=800'
            },
            {
              name: 'BUŁKA SAMO MIĘSO',
              description: 'mięso, sos',
              prices: ['30 zł', '40 zł'],
              image: 'https://images.unsplash.com/photo-1561626423-a51b45dc0e65?auto=format&fit=crop&q=80&w=800'
            }
          ]
        },
        {
          title: 'FAST FOOD',
          subtitle: 'standard / duży',
          items: [
            {
              name: 'HAMBURGER',
              prices: ['15 zł', '18 zł'],
              image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&q=80&w=800'
            },
            {
              name: 'CHEESEBURGER',
              prices: ['16 zł', '20 zł'],
              image: 'https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&q=80&w=800'
            },
            {
              name: 'HOT-DOG',
              prices: ['20 zł', '24 zł'],
              image: 'https://images.unsplash.com/photo-1612392062631-94bcd88fa552?auto=format&fit=crop&q=80&w=800'
            },
            {
              name: 'FRYTKI',
              prices: ['10 zł', '15 zł'],
              image: 'https://images.unsplash.com/photo-1630384060421-cb20d0e0649d?auto=format&fit=crop&q=80&w=800'
            }
          ]
        },
        {
          title: 'KUBEŁEK',
          subtitle: 'mały / średni / duży',
          items: [
            {
              name: 'KEBAB KUBEŁEK',
              description: 'mięso, frytki, surówki, sos',
              prices: ['22 zł', '26 zł', '32 zł'],
              image: 'https://images.unsplash.com/photo-1529006557810-274b9b2fc783?auto=format&fit=crop&q=80&w=800'
            },
            {
              name: 'KUBEK Z SEREM',
              description: 'mięso, frytki, surówki, ser żółty, sos',
              prices: ['24 zł', '28 zł', '35 zł'],
              image: 'https://images.unsplash.com/photo-1542574271-7f3b92e6c821?auto=format&fit=crop&q=80&w=800'
            },
            {
              name: 'KUBEK SAMO MIĘSO',
              description: 'mięso, sos',
              prices: ['25 zł', '30 zł', '38 zł'],
              image: 'https://images.unsplash.com/photo-1561626423-a51b45dc0e65?auto=format&fit=crop&q=80&w=800'
            }
          ]
        },
        {
          title: 'SPECJAŁY',
          items: [
            {
              name: 'ZAFER SPECJAŁ DLA 4 OSOBY',
              description: 'mięso wołowina i kurczak, sałatki, frytki, 5 szt. nuggets, 2 szt. polędwiczek, 2 szt. sticks mozzarella, 2 x sos',
              price: '120 zł',
              image: 'https://images.unsplash.com/photo-1529006557810-274b9b2fc783?auto=format&fit=crop&q=80&w=800'
            },
            {
              name: 'KEBAB NA TALERZU',
              description: 'mięso, surówki, frytki, sos',
              subtitle: 'standard / podwójny',
              prices: ['36 zł', '45 zł'],
              image: 'https://images.unsplash.com/photo-1529006557810-274b9b2fc783?auto=format&fit=crop&q=80&w=800'
            },
            {
              name: 'KAPSALON',
              description: 'mięso, frytki, surówki, ser żółty, sos',
              price: '36 zł',
              image: 'https://images.unsplash.com/photo-1542574271-7f3b92e6c821?auto=format&fit=crop&q=80&w=800'
            },
            {
              name: 'FALAFEL W CIEŚCIE',
              description: 'falafel + sos, surówki, frytki, sos',
              price: '22 zł',
              image: 'https://images.unsplash.com/photo-1593001874117-c99c900c6c0e?auto=format&fit=crop&q=80&w=800'
            }
          ]
        },
        {
          title: 'DODATKI',
          items: [
            {
              name: 'DODATKOWY SOS, SER',
              price: '3 zł'
            },
            {
              name: 'MIĘSO KRAFTOWE',
              price: '7 zł'
            },
            {
              name: 'DODATKOWE MIĘSO',
              price: '5 zł'
            },
            {
              name: 'OPAKOWANIE',
              price: '2 zł'
            }
          ]
        },
        {
          title: 'NAPOJE 0.5 L',
          items: [
            {
              name: 'PEPSI',
              price: '8 zł',
              image: 'https://images.unsplash.com/photo-1553456558-aff63285bdd1?auto=format&fit=crop&q=80&w=800'
            },
            {
              name: 'MIRINDA',
              price: '8 zł',
              image: 'https://images.unsplash.com/photo-1625772299848-391b6a87d7b3?auto=format&fit=crop&q=80&w=800'
            },
            {
              name: '7UP',
              price: '8 zł',
              image: 'https://images.unsplash.com/photo-1625772299848-391b6a87d7b3?auto=format&fit=crop&q=80&w=800'
            },
            {
              name: 'ICE TEA',
              price: '8 zł',
              image: 'https://images.unsplash.com/photo-1556881286-fc6915169721?auto=format&fit=crop&q=80&w=800'
            },
            {
              name: 'WODA',
              price: '5 zł',
              image: 'https://images.unsplash.com/photo-1560023907-5f339617ea30?auto=format&fit=crop&q=80&w=800'
            },
            {
              name: 'AYRAN',
              price: '5 zł',
              image: 'https://images.unsplash.com/photo-1541658016709-82535e94bc69?auto=format&fit=crop&q=80&w=800'
            }
          ]
        }
      ]
    }
  };

  const renderPizzaMenu = () => (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
    >
      {menuData.pizza.items.map((item, index) => (
        <motion.div
          key={index}
          variants={itemVariants}
          className="bg-white rounded-lg shadow-md overflow-hidden"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <div className="relative h-48">
            <motion.img
              src={item.image}
              alt={item.name}
              className="w-full h-full object-cover"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3 }}
            />
            <div className="absolute top-0 right-0 bg-red-600 text-white px-4 py-2 rounded-bl-lg">
              {item.price}
            </div>
          </div>
          <div className="p-6">
            <h3 className="text-xl font-semibold mb-2">{item.name}</h3>
            <p className="text-gray-600 mb-4">{item.description}</p>
            <motion.button
              className="w-full bg-red-600 text-white py-2 rounded-md hover:bg-red-700 transition-colors flex items-center justify-center gap-2"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => handleAddToCart(item)}
            >
              <ShoppingBag size={20} />
              Add to Cart
            </motion.button>
          </div>
        </motion.div>
      ))}
    </motion.div>
  );

  const renderKebabMenu = () => (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-12"
    >
      {menuData.kebab.categories.map((category, categoryIndex) => (
        <motion.div
          key={categoryIndex}
          variants={itemVariants}
          className="bg-white rounded-lg shadow-md p-6"
        >
          <h2 className="text-2xl font-bold mb-2">{category.title}</h2>
          {category.subtitle && (
            <p className="text-gray-600 mb-6">{category.subtitle}</p>
          )}
          <motion.div
            variants={containerVariants}
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {category.items.map((item, itemIndex) => (
              <motion.div
                key={itemIndex}
                variants={itemVariants}
                className="bg-gray-50 rounded-lg p-4"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                {item.image && (
                  <div className="relative h-48 mb-4">
                    <motion.img
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover rounded-lg"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 0.3 }}
                    />
                  </div>
                )}
                <h3 className="text-lg font-semibold mb-2">{item.name}</h3>
                {item.description && (
                  <p className="text-gray-600 text-sm mb-3">{item.description}</p>
                )}
                <div className="flex flex-wrap gap-2">
                  {item.prices ? (
                    item.prices.map((price, priceIndex) => {
                      const sizes = ['small', 'medium', 'large', 'mega'];
                      return (
                        <motion.button
                          key={priceIndex}
                          className="bg-red-600 text-white px-4 py-2 rounded-md text-sm flex items-center gap-2"
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          onClick={() => handleAddToCart(item, sizes[priceIndex])}
                        >
                          <ShoppingBag size={16} />
                          <span className="capitalize">{sizes[priceIndex]}</span>
                          <span>{price}</span>
                        </motion.button>
                      );
                    })
                  ) : (
                    <motion.button
                      className="bg-red-600 text-white px-4 py-2 rounded-md text-sm flex items-center gap-2"
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => handleAddToCart(item)}
                    >
                      <ShoppingBag size={16} />
                      Add to Cart - {item.price}
                    </motion.button>
                  )}
                </div>
              </motion.div>
            ))}
          </motion.div>
        </motion.div>
      ))}
    </motion.div>
  );

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-4xl font-bold text-center mb-8"
        >
          Our Menu
        </motion.h1>
        
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex justify-center space-x-4 mb-12"
        >
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setActiveMenu('pizza')}
            className={`px-8 py-3 rounded-full font-semibold transition-colors ${
              activeMenu === 'pizza'
                ? 'bg-red-600 text-white'
                : 'bg-white text-gray-700 hover:bg-gray-100'
            }`}
          >
            Pizza Menu
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setActiveMenu('kebab')}
            className={`px-8 py-3 rounded-full font-semibold transition-colors ${
              activeMenu === 'kebab'
                ? 'bg-red-600 text-white'
                : 'bg-white text-gray-700 hover:bg-gray-100'
            }`}
          >
            Kebab Menu
          </motion.button>
        </motion.div>

        <AnimatePresence mode="wait">
          <motion.div
            key={activeMenu}
            initial={{ opacity: 0, x: activeMenu === 'pizza' ? -20 : 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: activeMenu === 'pizza' ? 20 : -20 }}
            transition={{ duration: 0.3 }}
          >
            {activeMenu === 'pizza' ? renderPizzaMenu() : renderKebabMenu()}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
};

export default MenuPage;