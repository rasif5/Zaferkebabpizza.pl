import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { ArrowRight, Star, Clock, MapPin, Phone, ChefHat, Award, Utensils } from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion, useScroll, useTransform, useSpring } from 'framer-motion';

const heroTexts = {
  pl: [
    {
      title: "Tradycyjny Smak w Nowoczesnym Wydaniu",
      subtitle: "Witamy w Zafer Kebab & Pizza - miejscu, gdzie tradycyjne receptury spotykają się z nowoczesnymi technikami kulinarnymi."
    },
    {
      title: "Odkryj Prawdziwe Smaki Orientu",
      subtitle: "Autentyczne przepisy, starannie dobrane składniki i pasja do gotowania w każdym naszym daniu."
    },
    {
      title: "Najlepszy Kebab w Katowicach",
      subtitle: "Świeżo przygotowywane mięso z własnej marynaty, domowe sosy i chrupiące warzywa."
    },
    {
      title: "Twoje Ulubione Smaki Blisko Ciebie",
      subtitle: "Szybka dostawa, świeże składniki i niezapomniane doznania kulinarne czekają na Ciebie."
    }
  ],
  en: [
    {
      title: "Traditional Taste with a Modern Twist",
      subtitle: "Welcome to Zafer Kebab & Pizza - where traditional recipes meet modern culinary techniques."
    },
    {
      title: "Discover Authentic Oriental Flavors",
      subtitle: "Genuine recipes, carefully selected ingredients, and passion for cooking in every dish."
    },
    {
      title: "Best Kebab in Katowice",
      subtitle: "Freshly prepared meat from our own marinade, homemade sauces, and crispy vegetables."
    },
    {
      title: "Your Favorite Flavors Close to You",
      subtitle: "Fast delivery, fresh ingredients, and unforgettable culinary experiences await you."
    }
  ],
  ru: [
    {
      title: "Традиционный Вкус в Современном Исполнении",
      subtitle: "Добро пожаловать в Zafer Kebab & Pizza - место, где традиционные рецепты встречаются с современными кулинарными техниками."
    },
    {
      title: "Откройте Настоящие Восточные Вкусы",
      subtitle: "Аутентичные рецепты, тщательно отобранные ингредиенты и страсть к приготовлению в каждом нашем блюде."
    },
    {
      title: "Лучший Кебаб в Катовице",
      subtitle: "Свежеприготовленное мясо из собственного маринада, домашние соусы и хрустящие овощи."
    },
    {
      title: "Ваши Любимые Вкусы Рядом с Вами",
      subtitle: "Быстрая доставка, свежие ингредиенты и незабываемые кулинарные впечатления ждут вас."
    }
  ]
};

const HomePage = () => {
  const { t, i18n } = useTranslation();
  const { scrollY } = useScroll();
  const [textIndex, setTextIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setTextIndex((current) => (current + 1) % heroTexts[i18n.language as keyof typeof heroTexts].length);
    }, 5000); // Change text every 5 seconds

    return () => clearInterval(interval);
  }, [i18n.language]);

  const backgroundY = useTransform(scrollY, [0, 500], [0, 150]);
  const backgroundScale = useTransform(scrollY, [0, 500], [1.1, 1.3]);
  const opacity = useTransform(scrollY, [0, 300], [1, 0]);

  const springConfig = { stiffness: 100, damping: 30, restDelta: 0.001 };
  const scaleSpring = useSpring(1, springConfig);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { 
      opacity: 0,
      y: 20
    },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5,
        ease: "easeOut"
      }
    }
  };

  const cardVariants = {
    hidden: { opacity: 0, scale: 0.8 },
    visible: {
      opacity: 1,
      scale: 1,
      transition: {
        duration: 0.6,
        ease: "easeOut",
      },
    },
    hover: {
      scale: 1.05,
      transition: {
        duration: 0.2,
      },
    },
    tap: {
      scale: 0.95,
    },
  };

  const floatingAnimation = {
    y: [0, -10, 0],
    transition: {
      duration: 2,
      repeat: Infinity,
      ease: "easeInOut",
    },
  };

  const currentTexts = heroTexts[i18n.language as keyof typeof heroTexts] || heroTexts.en;

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative h-[100vh] overflow-hidden">
        <motion.div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: 'url("https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=2070")',
            y: backgroundY,
            scale: backgroundScale,
          }}
        />
        <motion.div 
          className="absolute inset-0 bg-black"
          style={{ opacity: useTransform(scrollY, [0, 300], [0.5, 0.8]) }}
        />
        <motion.div
          className="relative h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col justify-center text-white"
          style={{ opacity }}
        >
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="max-w-3xl"
          >
            <motion.h1
              key={textIndex}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -30 }}
              transition={{ duration: 0.8 }}
              className="text-4xl sm:text-5xl md:text-7xl font-bold mb-4 sm:mb-6 leading-tight"
            >
              {currentTexts[textIndex].title}
            </motion.h1>
            <motion.p
              key={`subtitle-${textIndex}`}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -30 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-lg sm:text-xl md:text-2xl mb-6 sm:mb-8 leading-relaxed"
            >
              {currentTexts[textIndex].subtitle}
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.8 }}
              className="w-full sm:w-auto"
            >
              <Link
                to="/menu"
                className="w-full sm:w-auto bg-red-600 hover:bg-red-700 text-white px-6 sm:px-8 py-3 sm:py-4 rounded-full font-semibold flex items-center justify-center text-base sm:text-lg group"
              >
                {t('home.hero.reserveButton')}
                <motion.span
                  animate={{ x: [0, 5, 0] }}
                  transition={{ duration: 1, repeat: Infinity }}
                >
                  <ArrowRight className="ml-2 h-5 w-5" />
                </motion.span>
              </Link>
            </motion.div>
          </motion.div>
        </motion.div>
      </section>

      {/* Specialties Section */}
      <section className="py-12 sm:py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={containerVariants}
            className="text-center mb-8 sm:mb-12"
          >
            <motion.h2 
              variants={itemVariants}
              className="text-2xl sm:text-3xl md:text-4xl font-bold mb-3 sm:mb-4"
            >
              {t('home.specialties.title')}
            </motion.h2>
            <motion.p 
              variants={itemVariants}
              className="text-gray-600 max-w-2xl mx-auto px-4 sm:px-0"
            >
              {t('home.specialties.subtitle')}
            </motion.p>
          </motion.div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8">
            <motion.div
              variants={cardVariants}
              initial="hidden"
              whileInView="visible"
              whileHover="hover"
              whileTap="tap"
              viewport={{ once: true }}
              className="relative overflow-hidden rounded-lg shadow-lg transform-gpu"
            >
              <motion.img
                src="https://images.unsplash.com/photo-1590947132387-155cc02f3212?auto=format&fit=crop&q=80&w=2070"
                alt="Kebab"
                className="w-full h-56 sm:h-72 object-cover"
                whileHover={{ scale: 1.1 }}
                transition={{ duration: 0.6 }}
              />
              <motion.div 
                className="absolute inset-0 bg-gradient-to-t from-black/75 to-transparent flex items-end p-4 sm:p-6"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ delay: 0.2 }}
              >
                <div className="text-white">
                  <motion.h3 
                    className="text-xl sm:text-2xl font-bold mb-2"
                    animate={floatingAnimation}
                  >
                    {t('home.specialties.kebab.title')}
                  </motion.h3>
                  <motion.p 
                    className="text-sm sm:text-base mb-3 sm:mb-4"
                    initial={{ opacity: 0 }}
                    whileInView={{ opacity: 1 }}
                    transition={{ delay: 0.4 }}
                  >
                    {t('home.specialties.kebab.description')}
                  </motion.p>
                  <motion.div
                    whileHover={{ x: 10 }}
                    transition={{ type: "spring", stiffness: 400 }}
                  >
                    <Link
                      to="/menu"
                      className="inline-flex items-center text-white hover:text-red-200"
                    >
                      {t('home.specialties.kebab.link')} <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </motion.div>
                </div>
              </motion.div>
            </motion.div>
            <motion.div
              variants={cardVariants}
              initial="hidden"
              whileInView="visible"
              whileHover="hover"
              whileTap="tap"
              viewport={{ once: true }}
              className="relative overflow-hidden rounded-lg shadow-lg transform-gpu"
            >
              <motion.img
                src="https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?auto=format&fit=crop&q=80&w=2070"
                alt="Dodatki"
                className="w-full h-56 sm:h-72 object-cover"
                whileHover={{ scale: 1.1 }}
                transition={{ duration: 0.6 }}
              />
              <motion.div 
                className="absolute inset-0 bg-gradient-to-t from-black/75 to-transparent flex items-end p-4 sm:p-6"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ delay: 0.2 }}
              >
                <div className="text-white">
                  <motion.h3 
                    className="text-xl sm:text-2xl font-bold mb-2"
                    animate={floatingAnimation}
                  >
                    {t('home.specialties.extras.title')}
                  </motion.h3>
                  <motion.p 
                    className="text-sm sm:text-base mb-3 sm:mb-4"
                    initial={{ opacity: 0 }}
                    whileInView={{ opacity: 1 }}
                    transition={{ delay: 0.4 }}
                  >
                    {t('home.specialties.extras.description')}
                  </motion.p>
                  <motion.div
                    whileHover={{ x: 10 }}
                    transition={{ type: "spring", stiffness: 400 }}
                  >
                    <Link
                      to="/menu"
                      className="inline-flex items-center text-white hover:text-red-200"
                    >
                      {t('home.specialties.extras.link')} <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </motion.div>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-12 sm:py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={containerVariants}
            className="text-center mb-8 sm:mb-12"
          >
            <motion.h2 
              variants={itemVariants}
              className="text-2xl sm:text-3xl md:text-4xl font-bold mb-3 sm:mb-4"
            >
              {t('home.whyUs.title')}
            </motion.h2>
            <motion.p 
              variants={itemVariants}
              className="text-gray-600 max-w-2xl mx-auto px-4 sm:px-0"
            >
              {t('home.whyUs.subtitle')}
            </motion.p>
          </motion.div>
          <motion.div 
            className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6 sm:gap-8"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            {[
              { icon: ChefHat, title: t('home.whyUs.features.chefs.title'), desc: t('home.whyUs.features.chefs.description') },
              { icon: Award, title: t('home.whyUs.features.ingredients.title'), desc: t('home.whyUs.features.ingredients.description') },
              { icon: Clock, title: t('home.whyUs.features.delivery.title'), desc: t('home.whyUs.features.delivery.description') },
              { icon: Utensils, title: t('home.whyUs.features.fresh.title'), desc: t('home.whyUs.features.fresh.description') }
            ].map((item, index) => (
              <motion.div
                key={index}
                variants={cardVariants}
                whileHover="hover"
                whileTap="tap"
                className="text-center p-4 sm:p-6 bg-white rounded-lg shadow-md transform-gpu"
              >
                <motion.div
                  animate={floatingAnimation}
                  className="flex justify-center"
                >
                  <item.icon className="h-10 w-10 sm:h-12 sm:w-12 text-red-600" />
                </motion.div>
                <motion.h3 
                  className="text-lg sm:text-xl font-semibold mb-2 mt-3 sm:mt-4"
                  variants={itemVariants}
                >
                  {item.title}
                </motion.h3>
                <motion.p 
                  className="text-sm sm:text-base text-gray-600"
                  variants={itemVariants}
                >
                  {item.desc}
                </motion.p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Contact & Location Section */}
      <section className="py-12 sm:py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
            <motion.div 
              className="space-y-4 sm:space-y-6"
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <motion.div 
                className="flex items-center space-x-3"
                whileHover={{ x: 10 }}
              >
                <MapPin className="h-5 w-5 sm:h-6 sm:w-6 text-red-600" />
                <span className="text-base sm:text-lg">{t('home.contact.address')}</span>
              </motion.div>
              <motion.div 
                className="flex items-center space-x-3"
                whileHover={{ x: 10 }}
              >
                <Phone className="h-5 w-5 sm:h-6 sm:w-6 text-red-600" />
                <a href="tel:512928003" className="text-base sm:text-lg hover:text-red-600">{t('home.contact.phone')}</a>
              </motion.div>
              <motion.div 
                className="aspect-w-16 aspect-h-9 mt-4"
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
              >
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2551.5762600893386!2d19.020899776891713!3d50.24001197169676!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4716ce3832e6e0c5%3A0x29e07bf0b5c433f3!2sRolna%2063%2C%2040-555%20Katowice%2C%20Poland!5e0!3m2!1sen!2sus!4v1709234567890!5m2!1sen!2sus"
                  width="100%"
                  height="300"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  className="rounded-lg shadow-lg"
                ></iframe>
              </motion.div>
            </motion.div>
            <motion.div 
              className="space-y-6 sm:space-y-8"
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <motion.h2 
                className="text-2xl sm:text-3xl font-bold"
                animate={floatingAnimation}
              >
                {t('home.contact.title')}
              </motion.h2>
              <motion.div 
                className="grid grid-cols-1 gap-6"
                variants={containerVariants}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
              >
                <motion.div 
                  className="bg-gray-50 p-4 sm:p-6 rounded-lg"
                  variants={cardVariants}
                  whileHover="hover"
                >
                  <h3 className="text-lg sm:text-xl font-semibold mb-2">{t('home.contact.hours.title')}</h3>
                  <ul className="space-y-2">
                    {[
                      { days: t('home.contact.hours.weekdays'), hours: "11:00 - 22:00" },
                      { days: t('home.contact.hours.saturday'), hours: "12:00 - 23:00" },
                      { days: t('home.contact.hours.sunday'), hours: "12:00 - 22:00" }
                    ].map((schedule, index) => (
                      <motion.li 
                        key={index}
                        className="flex justify-between text-sm sm:text-base"
                        variants={itemVariants}
                      >
                        <span>{schedule.days}</span>
                        <span>{schedule.hours}</span>
                      </motion.li>
                    ))}
                  </ul>
                </motion.div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;