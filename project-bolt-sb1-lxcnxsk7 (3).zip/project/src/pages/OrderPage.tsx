import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useCart } from '../context/CartContext';
import { useOrderStore, OrderType } from '../stores/orderStore';
import OrderTracking from '../components/OrderTracking';
import { motion } from 'framer-motion';
import { Banknote, Truck, MapPin } from 'lucide-react';

const OrderPage = () => {
  const { t } = useTranslation();
  const { state, dispatch } = useCart();
  const { activeOrder, createOrder } = useOrderStore();
  const [orderType, setOrderType] = useState<OrderType>('delivery');
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    phone: '',
    email: '',
    address: '',
    postalCode: '',
    city: '',
    notes: '',
    cashAmount: '',
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const totalAmount = state.total + (orderType === 'delivery' ? 10 : 0); // Delivery fee only for delivery orders

  const handleSubmit = (e: React.ChangeEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    const cashAmount = parseFloat(formData.cashAmount);
    if (isNaN(cashAmount) || cashAmount < totalAmount) {
      alert('Please enter a valid cash amount that covers the total order value.');
      return;
    }

    createOrder({
      type: orderType,
      items: state.items,
      total: state.total,
      deliveryFee: orderType === 'delivery' ? 10 : 0,
      customerInfo: {
        firstName: formData.firstName,
        lastName: formData.lastName,
        phone: formData.phone,
        email: formData.email,
        ...(orderType === 'delivery' ? {
          address: formData.address,
          postalCode: formData.postalCode,
          city: formData.city,
        } : {}),
        notes: formData.notes,
      },
      changeNeeded: cashAmount - totalAmount,
    });

    // Clear cart after order is placed
    dispatch({ type: 'CLEAR_CART' });
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-bold text-center mb-12">Order Online</h1>
        
        <div className="grid md:grid-cols-3 gap-8">
          {/* Order Form */}
          <div className="md:col-span-2">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-2xl font-semibold mb-6">Order Details</h2>

              {/* Order Type Selection */}
              <div className="flex gap-4 mb-8">
                <button
                  type="button"
                  onClick={() => setOrderType('delivery')}
                  className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-lg border-2 ${
                    orderType === 'delivery'
                      ? 'border-red-600 bg-red-50 text-red-600'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <Truck className="w-5 h-5" />
                  <span>Delivery</span>
                </button>
                <button
                  type="button"
                  onClick={() => setOrderType('pickup')}
                  className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-lg border-2 ${
                    orderType === 'pickup'
                      ? 'border-red-600 bg-red-50 text-red-600'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <MapPin className="w-5 h-5" />
                  <span>Pickup</span>
                </button>
              </div>

              <form className="space-y-6" onSubmit={handleSubmit}>
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      First Name
                    </label>
                    <input
                      type="text"
                      name="firstName"
                      value={formData.firstName}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-red-500 focus:border-red-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Last Name
                    </label>
                    <input
                      type="text"
                      name="lastName"
                      value={formData.lastName}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-red-500 focus:border-red-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-red-500 focus:border-red-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-red-500 focus:border-red-500"
                  />
                </div>

                {orderType === 'delivery' && (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Delivery Address
                      </label>
                      <input
                        type="text"
                        name="address"
                        value={formData.address}
                        onChange={handleInputChange}
                        required
                        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-red-500 focus:border-red-500"
                        placeholder="Street Address"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Postal Code
                        </label>
                        <input
                          type="text"
                          name="postalCode"
                          value={formData.postalCode}
                          onChange={handleInputChange}
                          required
                          className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-red-500 focus:border-red-500"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          City
                        </label>
                        <input
                          type="text"
                          name="city"
                          value={formData.city}
                          onChange={handleInputChange}
                          required
                          className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-red-500 focus:border-red-500"
                        />
                      </div>
                    </div>
                  </>
                )}

                {orderType === 'pickup' && (
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="font-medium mb-2">Pickup Location</h3>
                    <div className="flex items-center text-gray-600">
                      <MapPin className="w-5 h-5 mr-2" />
                      <p>ul. Rolna 63, Katowice</p>
                    </div>
                    <p className="text-sm text-gray-500 mt-2">
                      Your order will be ready for pickup in approximately 20-30 minutes.
                    </p>
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Cash Amount
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Banknote className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                      type="number"
                      name="cashAmount"
                      value={formData.cashAmount}
                      onChange={handleInputChange}
                      required
                      min={totalAmount}
                      step="0.01"
                      className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-red-500 focus:border-red-500"
                      placeholder={`Minimum ${totalAmount.toFixed(2)} zł`}
                    />
                  </div>
                  <p className="mt-1 text-sm text-gray-500">
                    Please enter the cash amount you'll pay with. We'll prepare the change.
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Additional Notes
                  </label>
                  <textarea
                    name="notes"
                    value={formData.notes}
                    onChange={handleInputChange}
                    rows={4}
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-red-500 focus:border-red-500"
                    placeholder="Any special instructions?"
                  ></textarea>
                </div>

                <motion.button
                  type="submit"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full bg-red-600 text-white py-3 rounded-md hover:bg-red-700 transition-colors"
                >
                  Place Order
                </motion.button>
              </form>
            </div>
          </div>

          {/* Order Summary and Tracking */}
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-2xl font-semibold mb-6">Order Summary</h2>
              <div className="space-y-4">
                {state.items.map((item) => (
                  <div key={item.id} className="flex justify-between items-center pb-4 border-b">
                    <div>
                      <h3 className="font-semibold">{item.name}</h3>
                      {item.size && (
                        <p className="text-sm text-gray-500 capitalize">Size: {item.size}</p>
                      )}
                      <p className="text-sm text-gray-500">Quantity: {item.quantity}</p>
                    </div>
                    <span className="font-medium">{item.price}</span>
                  </div>
                ))}
                <div className="flex justify-between items-center pb-4 border-b">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="font-medium">{state.total.toFixed(2)} zł</span>
                </div>
                {orderType === 'delivery' && (
                  <div className="flex justify-between items-center pb-4 border-b">
                    <span className="text-gray-600">Delivery Fee</span>
                    <span className="font-medium">10.00 zł</span>
                  </div>
                )}
                <div className="flex justify-between items-center text-lg font-semibold">
                  <span>Total</span>
                  <span>{totalAmount.toFixed(2)} zł</span>
                </div>

                <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center text-gray-700">
                    <Banknote className="h-5 w-5 mr-2" />
                    <span>Cash payment only</span>
                  </div>
                  <p className="text-sm text-gray-500 mt-1">
                    Please have the exact amount or we'll bring change
                  </p>
                </div>
              </div>
            </div>

            {/* Order Tracking */}
            {activeOrder && <OrderTracking order={activeOrder} />}
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderPage;