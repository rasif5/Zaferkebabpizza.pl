import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../hooks/useAuth';
import { format } from 'date-fns';
import {
  LogOut,
  Users,
  ShoppingBag,
  Calendar,
  Settings,
  Edit,
  Trash2,
  Plus,
  AlertTriangle,
  CheckCircle2,
  X,
  Save,
  Search,
  Filter,
  ChevronDown,
  BarChart2,
  DollarSign,
  Package,
  Clock,
  Bell,
  Printer,
  FileText,
  Truck,
  Coffee,
  Pizza,
  Utensils,
  Phone
} from 'lucide-react';
import { useMenuStore } from '../stores/menuStore';
import { useOrderStore } from '../stores/orderStore';
import { useCustomerStore } from '../stores/customerStore';
import { useAnalyticsStore } from '../stores/analyticsStore';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const AdminPage = () => {
  const { logout } = useAuth();
  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState('dashboard');
  const menuStore = useMenuStore();
  const orderStore = useOrderStore();
  const customerStore = useCustomerStore();
  const analyticsStore = useAnalyticsStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');
  const [dateRange, setDateRange] = useState('today');
  const [notifications, setNotifications] = useState([
    { id: 1, message: 'New order received', time: '5 minutes ago', unread: true },
    { id: 2, message: 'Item out of stock', time: '1 hour ago', unread: false },
  ]);

  const stats = {
    totalOrders: orderStore.orders.length,
    totalRevenue: orderStore.orders.reduce((sum, order) => sum + order.total, 0),
    activeCustomers: customerStore.customers.length,
    pendingOrders: orderStore.orders.filter(order => order.status === 'pending').length
  };

  const handleLogout = () => {
    logout();
    navigate('/admin/login');
  };

  const renderDashboard = () => (
    <div className="space-y-6">
      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="p-4 bg-green-100 rounded-lg flex items-center justify-center gap-3 text-green-700"
          onClick={() => setActiveSection('orders')}
        >
          <Package className="w-5 h-5" />
          <span>New Order</span>
        </motion.button>
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="p-4 bg-blue-100 rounded-lg flex items-center justify-center gap-3 text-blue-700"
          onClick={() => setActiveSection('menu')}
        >
          <Pizza className="w-5 h-5" />
          <span>Add Menu Item</span>
        </motion.button>
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="p-4 bg-purple-100 rounded-lg flex items-center justify-center gap-3 text-purple-700"
          onClick={() => window.print()}
        >
          <Printer className="w-5 h-5" />
          <span>Print Reports</span>
        </motion.button>
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="p-4 bg-orange-100 rounded-lg flex items-center justify-center gap-3 text-orange-700"
          onClick={() => setActiveSection('settings')}
        >
          <Settings className="w-5 h-5" />
          <span>Settings</span>
        </motion.button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-6 rounded-xl shadow-sm"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Today's Orders</p>
              <h3 className="text-2xl font-bold mt-1">{stats.totalOrders}</h3>
            </div>
            <div className="bg-blue-100 p-3 rounded-full">
              <Package className="w-6 h-6 text-blue-600" />
            </div>
          </div>
          <div className="mt-4">
            <span className="text-sm text-green-500">+12% from yesterday</span>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white p-6 rounded-xl shadow-sm"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Today's Revenue</p>
              <h3 className="text-2xl font-bold mt-1">{stats.totalRevenue.toFixed(2)} zł</h3>
            </div>
            <div className="bg-green-100 p-3 rounded-full">
              <DollarSign className="w-6 h-6 text-green-600" />
            </div>
          </div>
          <div className="mt-4">
            <span className="text-sm text-green-500">+8% from yesterday</span>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white p-6 rounded-xl shadow-sm"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Active Orders</p>
              <h3 className="text-2xl font-bold mt-1">{stats.pendingOrders}</h3>
            </div>
            <div className="bg-yellow-100 p-3 rounded-full">
              <Clock className="w-6 h-6 text-yellow-600" />
            </div>
          </div>
          <div className="mt-4">
            <span className="text-sm text-yellow-500">3 require attention</span>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white p-6 rounded-xl shadow-sm"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Average Order Time</p>
              <h3 className="text-2xl font-bold mt-1">32 min</h3>
            </div>
            <div className="bg-purple-100 p-3 rounded-full">
              <Clock className="w-6 h-6 text-purple-600" />
            </div>
          </div>
          <div className="mt-4">
            <span className="text-sm text-purple-500">Within target time</span>
          </div>
        </motion.div>
      </div>

      {/* Revenue Chart */}
      <div className="bg-white p-6 rounded-xl shadow-sm">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-lg font-semibold">Revenue Overview</h3>
          <select 
            className="border border-gray-300 rounded-lg px-3 py-1"
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
          >
            <option value="today">Today</option>
            <option value="week">This Week</option>
            <option value="month">This Month</option>
          </select>
        </div>
        <Line
          data={{
            labels: ['9:00', '12:00', '15:00', '18:00', '21:00'],
            datasets: [
              {
                label: 'Revenue',
                data: [500, 1200, 900, 1600, 2000],
                borderColor: 'rgb(220, 38, 38)',
                tension: 0.4,
              },
            ],
          }}
          options={{
            responsive: true,
            plugins: {
              legend: {
                display: false,
              },
            },
            scales: {
              y: {
                beginAtZero: true,
                ticks: {
                  callback: (value) => `${value} zł`,
                },
              },
            },
          }}
        />
      </div>

      {/* Active Orders */}
      <div className="bg-white p-6 rounded-xl shadow-sm">
        <h3 className="text-lg font-semibold mb-4">Active Orders</h3>
        <div className="space-y-4">
          {orderStore.orders
            .filter(order => ['pending', 'preparing', 'ready_for_delivery'].includes(order.status))
            .slice(0, 5)
            .map((order) => (
            <motion.div
              key={order.id}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
            >
              <div className="flex items-center gap-4">
                <div className={`w-3 h-3 rounded-full ${
                  order.status === 'pending' ? 'bg-yellow-500' :
                  order.status === 'preparing' ? 'bg-blue-500' :
                  'bg-green-500'
                }`} />
                <div>
                  <p className="font-medium">Order #{order.id}</p>
                  <p className="text-sm text-gray-500">
                    {order.customerInfo.firstName} {order.customerInfo.lastName}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-medium">{order.total.toFixed(2)} zł</p>
                <p className="text-sm text-gray-500">
                  {format(new Date(order.timestamps.created), 'HH:mm')}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Popular Items & Customer Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm">
          <h3 className="text-lg font-semibold mb-4">Popular Items</h3>
          <div className="space-y-4">
            {menuStore.items.slice(0, 5).map((item) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
              >
                <div className="flex items-center">
                  {item.image && (
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-12 h-12 rounded-lg object-cover mr-4"
                    />
                  )}
                  <div>
                    <p className="font-medium">{item.name}</p>
                    <p className="text-sm text-gray-500">{item.category}</p>
                  </div>
                </div>
                <p className="font-medium">
                  {Array.isArray(item.price) ? item.price[0] : item.price}
                </p>
              </motion.div>
            ))}
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm">
          <h3 className="text-lg font-semibold mb-4">Recent Customers</h3>
          <div className="space-y-4">
            {customerStore.customers.slice(0, 5).map((customer) => (
              <motion.div
                key={customer.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
              >
                <div>
                  <p className="font-medium">
                    {customer.firstName} {customer.lastName}
                  </p>
                  <p className="text-sm text-gray-500">{customer.phone}</p>
                </div>
                <div className="text-right">
                  <p className="font-medium">{customer.loyaltyPoints} points</p>
                  <p className="text-sm text-gray-500">
                    {format(new Date(customer.joinDate), 'PP')}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold text-gray-900">Restaurant Dashboard</h1>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <button className="p-2 text-gray-400 hover:text-gray-500">
                  <Bell className="w-6 h-6" />
                  <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full"></span>
                </button>
              </div>
              <button
                onClick={handleLogout}
                className="flex items-center text-red-600 hover:text-red-700"
              >
                <LogOut className="w-5 h-5 mr-2" />
                Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
          {/* Navigation */}
          <div className="md:col-span-1 space-y-4">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setActiveSection('dashboard')}
              className={`w-full flex items-center p-4 rounded-lg ${
                activeSection === 'dashboard'
                  ? 'bg-red-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              <BarChart2 className="w-5 h-5 mr-3" />
              Dashboard
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setActiveSection('orders')}
              className={`w-full flex items-center p-4 rounded-lg ${
                activeSection === 'orders'
                  ? 'bg-red-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              <Package className="w-5 h-5 mr-3" />
              Orders
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setActiveSection('menu')}
              className={`w-full flex items-center p-4 rounded-lg ${
                activeSection === 'menu'
                  ? 'bg-red-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              <Utensils className="w-5 h-5 mr-3" />
              Menu
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setActiveSection('customers')}
              className={`w-full flex items-center p-4 rounded-lg ${
                activeSection === 'customers'
                  ? 'bg-red-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              <Users className="w-5 h-5 mr-3" />
              Customers
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setActiveSection('kitchen')}
              className={`w-full flex items-center p-4 rounded-lg ${
                activeSection === 'kitchen'
                  ? 'bg-red-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              <Coffee className="w-5 h-5 mr-3" />
              Kitchen Display
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setActiveSection('delivery')}
              className={`w-full flex items-center p-4 rounded-lg ${
                activeSection === 'delivery'
                  ? 'bg-red-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              <Truck className="w-5 h-5 mr-3" />
              Delivery
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setActiveSection('reports')}
              className={`w-full flex items-center p-4 rounded-lg ${
                activeSection === 'reports'
                  ? 'bg-red-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              <FileText className="w-5 h-5 mr-3" />
              Reports
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setActiveSection('settings')}
              className={`w-full flex items-center p-4 rounded-lg ${
                activeSection === 'settings'
                  ? 'bg-red-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              <Settings className="w-5 h-5 mr-3" />
              Settings
            </motion.button>
          </div>

          {/* Content Area */}
          <div className="md:col-span-4">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeSection}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="bg-white rounded-xl shadow-sm p-6"
              >
                {activeSection === 'dashboard' && renderDashboard()}

                {activeSection === 'orders' && (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <h2 className="text-xl font-semibold">Orders Management</h2>
                      <div className="flex items-center space-x-4">
                        <select className="border border-gray-300 rounded-lg px-4 py-2">
                          <option value="all">All Status</option>
                          <option value="pending">Pending</option>
                          <option value="preparing">Preparing</option>
                          <option value="delivered">Delivered</option>
                        </select>
                        <button className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700">
                          New Order
                        </button>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      {orderStore.orders.map((order) => (
                        <motion.div
                          key={order.id}
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="bg-white p-6 rounded-xl shadow-sm border border-gray-200"
                        >
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-semibold text-lg">Order #{order.id}</h3>
                              <p className="text-gray-600">
                                {order.customerInfo.firstName} {order.customerInfo.lastName}
                              </p>
                              <p className="text-sm text-gray-500">
                                {format(new Date(order.timestamps.created), 'PPp')}
                              </p>
                            </div>
                            <div className="text-right">
                              <p className="text-lg font-semibold">{order.total.toFixed(2)} zł</p>
                              <select
                                value={order.status}
                                onChange={(e) => {
                                  orderStore.updateOrderStatus(order.id, e.target.value as any);
                                }}
                                className="mt-2 border border-gray-300 rounded-lg px-3 py-1 text-sm"
                              >
                                <option value="pending">Pending</option>
                                <option value="confirmed">Confirmed</option>
                                <option value="preparing">Preparing</option>
                                <option value="ready_for_delivery">Ready for Delivery</option>
                                <option value="out_for_delivery">Out for Delivery</option>
                                <option value="delivered">Delivered</option>
                                <option value="cancelled">Cancelled</option>
                              </select>
                            </div>
                          </div>
                          
                          <div className="mt-4 pt-4 border-t border-gray-200">
                            <h4 className="font-medium mb-2">Order Items</h4>
                            <div className="space-y-2">
                              {order.items.map((item, index) => (
                                <div key={index} className="flex justify-between text-sm">
                                  <span>
                                    {item.quantity}x {item.name}
                                    {item.size && ` (${item.size})`}
                                  </span>
                                  <span>{item.price}</span>
                                </div>
                              ))}
                            </div>
                          </div>

                          <div className="mt-4 pt-4 border-t border-gray-200 flex justify-between">
                            <div className="space-x-2">
                              <button className="px-3 py-1 bg-blue-100 text-blue-700 rounded-lg text-sm">
                                Print
                              </button>
                              
                              <button className="px-3 py-1 bg-green-100 text-green-700 rounded-lg text-sm">
                                Send to Kitchen
                              </button>
                            </div>
                            <div className="space-x-2">
                              <button className="px-3 py-1 bg-yellow-100 text-yellow-700 rounded-lg text-sm">
                                Edit
                              </button>
                              <button className="px-3 py-1 bg-red-100 text-red-700 rounded-lg text-sm">
                                Cancel
                              </button>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                )}

                {activeSection === 'menu' && (
                  <div className="space-y-8">
                    <div className="flex items-center justify-between">
                      <div className="flex-1 max-w-sm">
                        <div className="relative">
                          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                          <input
                            type="text"
                            placeholder="Search menu items..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-red-500 focus:border-red-500"
                          />
                        </div>
                      </div>
                      <div className="flex items-center space-x-4">
                        <select
                          value={filterCategory}
                          onChange={(e) => setFilterCategory(e.target.value)}
                          className="border border-gray-300 rounded-lg px-4 py-2 focus:ring-red-500 focus:border-red-500"
                        >
                          <option value="all">All Categories</option>
                          <option value="pizza">Pizza</option>
                          <option value="kebab">Kebab</option>
                          <option value="drinks">Drinks</option>
                          <option value="extras">Extras</option>
                        </select>
                        <button
                          className="flex items-center px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                        >
                          <Plus className="w-5 h-5 mr-2" />
                          Add Item
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {menuStore.items
                        .filter(item => 
                          (filterCategory === 'all' || item.category === filterCategory) &&
                          (item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           item.description?.toLowerCase().includes(searchTerm.toLowerCase()))
                        )
                        .map((item) => (
                        <motion.div
                          key={item.id}
                          layout
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          className="bg-white rounded-xl shadow-sm overflow-hidden border border-gray-200"
                        >
                          {item.image && (
                            <img
                              src={item.image}
                              alt={item.name}
                              className="w-full h-48 object-cover"
                            />
                          )}
                          <div className="p-4">
                            <div className="flex items-center justify-between mb-2">
                              <h3 className="font-semibold text-lg">{item.name}</h3>
                              <span
                                className={`px-2 py-1 text-xs rounded-full ${
                                  item.outOfStock
                                    ? 'bg-red-100 text-red-800'
                                    : item.available
                                    ? 'bg-green-100 text-green-800'
                                    : 'bg-yellow-100 text-yellow-800'
                                }`}
                              >
                                {item.outOfStock 
                                  ? 'Out of Stock' 
                                  : item.available 
                                  ? 'Available' 
                                  : 'Unavailable'}
                              </span>
                            </div>
                            <p className="text-gray-600 text-sm mb-4">{item.description}</p>
                            <div className="flex items-center justify-between">
                              <p className="font-medium">
                                {Array.isArray(item.price) ? item.price.join(' / ') : item.price}
                              </p>
                              <div className="flex items-center space-x-2">
                                <button
                                  className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg"
                                >
                                  <Edit size={18} />
                                </button>
                                <button
                                  onClick={() => menuStore.deleteItem(item.id)}
                                  className="p-2 text-red-600 hover:bg-red-50 rounded-lg"
                                >
                                  <Trash2 size={18} />
                                </button>
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                )}

                {activeSection === 'customers' && (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <h2 className="text-xl font-semibold">Customer Management</h2>
                      <div className="flex items-center space-x-4">
                        <input
                          type="text"
                          placeholder="Search customers..."
                          className="border border-gray-300 rounded-lg px-4 py-2"
                        />
                        <button className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700">
                          Add Customer
                        </button>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      {customerStore.customers.map((customer) => (
                        <motion.div
                          key={customer.id}
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="bg-white p-6 rounded-xl shadow-sm border border-gray-200"
                        >
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-semibold text-lg">
                                {customer.firstName} {customer.lastName}
                              </h3>
                              <div className="flex items-center gap-4 text-gray-600 mt-1">
                                <div className="flex items-center gap-1">
                                  <Phone size={16} />
                                  <span>{customer.phone}</span>
                                </div>
                                <span>{customer.email}</span>
                              </div>
                              <p className="text-sm text-gray-500 mt-2">{customer.address}</p>
                            </div>
                            <div className="text-right">
                              <div className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm">
                                {customer.loyaltyPoints} Points
                              </div>
                              <p className="text-sm text-gray-500 mt-2">
                                Joined: {format(new Date(customer.joinDate), 'PP')}
                              </p>
                            </div>
                          </div>
                          
                          <div className="mt-4 pt-4 border-t border-gray-200 flex justify-between items-center">
                            <div className="space-x-2">
                              <button className="px-3 py-1 bg-blue-100 text-blue-700 rounded-lg text-sm">
                                Order History
                              </button>
                              <button className="px-3 py-1 bg-purple-100 text-purple-700 rounded-lg text-sm">
                                Add Points
                              </button>
                            </div>
                            <div className="space-x-2">
                              <button className="px-3 py-1 bg-yellow-100 text-yellow-700 rounded-lg text-sm">
                                Edit
                              </button>
                              <button className="px-3 py-1 bg-red-100 text-red-700 rounded-lg text-sm">
                                Delete
                              </button>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                )}

                {activeSection === 'kitchen' && (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <h2 className="text-xl font-semibold">Kitchen Display System</h2>
                      <div className="flex items-center space-x-4">
                        <select className="border border-gray-300 rounded-lg px-4 py-2">
                          <option value="all">All Stations</option>
                          <option value="pizza">Pizza Station</option>
                          <option value="kebab">Kebab Station</option>
                          <option value="grill">Grill Station</option>
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {orderStore.orders
                        .filter(order => order.status === 'preparing')
                        .map((order) => (
                        <motion.div
                          key={order.id}
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="bg-white p-6 rounded-xl shadow-sm border-2 border-yellow-400"
                        >
                          <div className="flex justify-between items-start mb-4">
                            <div>
                              <h3 className="font-semibold text-lg">Order #{order.id}</h3>
                              <p className="text-sm text-gray-500">
                                Started: {format(new Date(order.timestamps.preparing!), 'HH:mm')}
                              </p>
                            </div>
                            <div className="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-sm">
                              {format(new Date(order.timestamps.preparing!), 'mm:ss')}
                            </div>
                          </div>

                          <div className="space-y-3">
                            {order.items.map((item, index) => (
                              <div
                                key={index}
                                className="flex items-center justify-between p-2 bg-gray-50 rounded-lg"
                              >
                                <div>
                                  <span className="font-medium">{item.quantity}x</span>
                                  <span className="ml-2">{item.name}</span>
                                  {item.size && (
                                    <span className="text-sm text-gray-500 ml-1">
                                      ({item.size})
                                    </span>
                                  )}
                                </div>
                                <button className="p-1 hover:bg-green-100 rounded">
                                  <CheckCircle2 
                                    className="w-5 h-5 text-green-600"
                                  />
                                </button>
                              </div>
                            ))}
                          </div>

                          <div className="mt-4 pt-4 border-t border-gray-200 flex justify-between">
                            <button className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">
                              Mark Ready
                            </button>
                            <button className="px-4 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200">
                              Issue Alert
                            </button>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                )}

                {activeSection === 'delivery' && (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <h2 className="text-xl font-semibold">Delivery Management</h2>
                      <div className="flex items-center space-x-4">
                        <select className="border border-gray-300 rounded-lg px-4 py-2">
                          <option value="all">All Drivers</option>
                          <option value="available">Available</option>
                          <option value="delivering">On Delivery</option>
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      <div className="bg-white p-6 rounded-xl shadow-sm">
                        <h3 className="font-semibold text-lg mb-4">Pending Deliveries</h3>
                        <div className="space-y-4">
                          {orderStore.orders
                            .filter(order => order.status === 'ready_for_delivery')
                            .map((order) => (
                            <motion.div
                              key={order.id}
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              className="p-4 bg-gray-50 rounded-lg"
                            >
                              <div className="flex justify-between items-start">
                                <div>
                                  <h4 className="font-medium">Order #{order.id}</h4>
                                  <p className="text-sm text-gray-600">
                                    {order.customerInfo.address}
                                  </p>
                                </div>
                                <span className="font-medium">
                                  {order.total.toFixed(2)} zł
                                </span>
                              </div>
                              <div className="mt-3 flex justify-end space-x-2">
                                <button className="px-3 py-1 bg-blue-100 text-blue-700 rounded text-sm">
                                  Assign Driver
                                </button>
                              </div>
                            </motion.div>
                          ))}
                        </div>
                      </div>

                      <div className="bg-white p-6 rounded-xl shadow-sm">
                        <h3 className="font-semibold text-lg mb-4">Active Deliveries</h3>
                        <div className="space-y-4">
                          {orderStore.orders
                            .filter(order => order.status === 'out_for_delivery')
                            .map((order) => (
                            <motion.div
                              key={order.id}
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              className="p-4 bg-gray-50 rounded-lg"
                            >
                              <div className="flex justify-between items-start">
                                <div>
                                  <h4 className="font-medium">Order #{order.id}</h4>
                                  <p className="text-sm text-gray-600">
                                    Driver: {order.deliveryDriver?.name}
                                  </p>
                                </div>
                                <div className="text-right">
                                  <span className="font-medium">
                                    {order.total.toFixed(2)} zł
                                  </span>
                                  <p className="text-sm text-gray-500">
                                    ETA: {format(new Date(order.estimatedTime!), 'HH:mm')}
                                  </p>
                                </div>
                              </div>
                            </motion.div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {activeSection === 'reports' && (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <h2 className="text-xl font-semibold">Reports & Analytics</h2>
                      <div className="flex items-center space-x-4">
                        <select className="border border-gray-300 rounded-lg px-4 py-2">
                          <option value="today">Today</option>
                          <option value="week">This Week</option>
                          <option value="month">This Month</option>
                          <option value="custom">Custom Range</option>
                        </select>
                        <button className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700">
                          Export Report
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="bg-white p-6 rounded-xl shadow-sm">
                        <h3 className="font-semibold text-lg mb-4">Sales by Category</h3>
                        <div className="h-64">
                          {/* Add chart component here */}
                        </div>
                      </div>

                      <div className="bg-white p-6 rounded-xl shadow-sm">
                        <h3 className="font-semibold text-lg mb-4">Popular Items</h3>
                        <div className="space-y-4">
                          {/* Add popular items list here */}
                        </div>
                      </div>

                      <div className="bg-white p-6 rounded-xl shadow-sm">
                        <h3 className="font-semibold text-lg mb-4">Delivery Performance</h3>
                        <div className="h-64">
                          {/* Add chart component here */}
                        </div>
                      </div>

                      <div className="bg-white p-6 rounded-xl shadow-sm">
                        <h3 className="font-semibold text-lg mb-4">Customer Insights</h3>
                        <div className="space-y-4">
                          {/* Add customer insights here */}
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {activeSection === 'settings' && (
                  <div className="space-y-6">
                    <div className="bg-white p-6 rounded-xl shadow-sm">
                      <h3 className="text-lg font-semibold mb-4">Restaurant Settings</h3>
                      <div className="space-y-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Restaurant Name
                          </label>
                          <input
                            type="text"
                            defaultValue="Zafer Kebab & Pizza"
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Address
                          </label>
                          <input
                            type="text"
                            defaultValue="ul. Rolna 63, Katowice"
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Phone Number
                          </label>
                          <input
                            type="tel"
                            defaultValue="512 928 003"
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                          />
                        </div>
                        <button className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700">
                          Save Changes
                        </button>
                      </div>
                    </div>

                    <div className="bg-white p-6 rounded-xl shadow-sm">
                      <h3 className="text-lg font-semibold mb-4">Delivery Settings</h3>
                      <div className="space-y-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Delivery Radius (km)
                          </label>
                          <input
                            type="number"
                            defaultValue="5"
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Minimum Order Amount
                          </label>
                          <input
                            type="number"
                            defaultValue="30"
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Delivery Fee
                          </label>
                          <input
                            type="number"
                            defaultValue="10"
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                          />
                        </div>
                        <button className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700">
                          Save Changes
                        </button>
                      </div>
                    </div>

                    <div className="bg-white p-6 rounded-xl shadow-sm">
                      <h3 className="text-lg font-semibold mb-4">Payment Settings</h3>
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <h4 className="font-medium">Cash Payments</h4>
                            <p className="text-sm text-gray-500">Accept cash payments on delivery</p>
                          </div>
                          <div className="relative">
                            <input type="checkbox" className="sr-only" id="cash" defaultChecked />
                            <label
                              htmlFor="cash"
                              className="bg-gray-200 relative inline-flex h-6 w-11 items-center rounded-full"
                            >
                              <span className="translate-x-6 inline-block h-4 w-4 transform rounded-full bg-white transition" />
                            </label>
                          </div>
                        </div>
                        <button className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700">
                          Save Changes
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </main>
    </div>
  );
};

export default AdminPage;