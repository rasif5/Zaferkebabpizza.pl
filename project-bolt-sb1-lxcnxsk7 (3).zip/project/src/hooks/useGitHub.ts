import { create } from 'zustand';
import { Octokit } from '@octokit/rest';

interface GitHubStore {
  isAuthenticated: boolean;
  token: string | null;
  octokit: Octokit | null;
  commits: any[];
  issues: any[];
  loading: boolean;
  error: string | null;
  initialize: (token: string) => void;
  fetchCommits: () => Promise<void>;
  fetchIssues: () => Promise<void>;
  createIssue: (title: string, body: string) => Promise<void>;
  logout: () => void;
}

const REPO_OWNER = 'yourusername';
const REPO_NAME = 'zafer-kebab';

export const useGitHub = create<GitHubStore>((set, get) => ({
  isAuthenticated: false,
  token: null,
  octokit: null,
  commits: [],
  issues: [],
  loading: false,
  error: null,

  initialize: (token) => {
    const octokit = new Octokit({ auth: token });
    set({ octokit, token, isAuthenticated: true });
  },

  fetchCommits: async () => {
    const { octokit } = get();
    if (!octokit) return;

    set({ loading: true, error: null });
    try {
      const { data } = await octokit.repos.listCommits({
        owner: REPO_OWNER,
        repo: REPO_NAME,
      });
      set({ commits: data, loading: false });
    } catch (error) {
      set({ error: 'Failed to fetch commits', loading: false });
    }
  },

  fetchIssues: async () => {
    const { octokit } = get();
    if (!octokit) return;

    set({ loading: true, error: null });
    try {
      const { data } = await octokit.issues.listForRepo({
        owner: REPO_OWNER,
        repo: REPO_NAME,
        state: 'all',
      });
      set({ issues: data, loading: false });
    } catch (error) {
      set({ error: 'Failed to fetch issues', loading: false });
    }
  },

  createIssue: async (title: string, body: string) => {
    const { octokit } = get();
    if (!octokit) return;

    set({ loading: true, error: null });
    try {
      await octokit.issues.create({
        owner: REPO_OWNER,
        repo: REPO_NAME,
        title,
        body,
      });
      await get().fetchIssues();
    } catch (error) {
      set({ error: 'Failed to create issue', loading: false });
    }
  },

  logout: () => {
    set({
      isAuthenticated: false,
      token: null,
      octokit: null,
      commits: [],
      issues: [],
    });
  },
}));