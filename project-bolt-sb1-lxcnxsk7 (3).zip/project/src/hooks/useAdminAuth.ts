import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { SignJWT, jwtVerify } from 'jose';

const secret = new TextEncoder().encode(import.meta.env.VITE_JWT_SECRET || 'your-secret-key');

interface AdminAuthStore {
  token: string | null;
  user: {
    id: string;
    email: string;
    role: 'admin' | 'manager';
  } | null;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  checkAuth: () => Promise<boolean>;
}

export const useAdminAuth = create<AdminAuthStore>()(
  persist(
    (set, get) => ({
      token: null,
      user: null,
      login: async (email: string, password: string) => {
        try {
          // In production, this should be an API call to your backend
          if (email === 'admin@zaferkebab.pl' && password === 'admin123') {
            const token = await new SignJWT({ 
              email,
              role: 'admin',
              id: '1'
            })
              .setProtectedHeader({ alg: 'HS256' })
              .setIssuedAt()
              .setExpirationTime('24h')
              .sign(secret);

            set({ 
              token,
              user: {
                id: '1',
                email,
                role: 'admin'
              }
            });
            return true;
          }
          return false;
        } catch (error) {
          console.error('Login error:', error);
          return false;
        }
      },
      logout: () => {
        set({ token: null, user: null });
      },
      checkAuth: async () => {
        const token = get().token;
        if (!token) return false;

        try {
          const { payload } = await jwtVerify(token, secret);
          return !!payload;
        } catch {
          set({ token: null, user: null });
          return false;
        }
      }
    }),
    {
      name: 'admin-auth',
      getStorage: () => localStorage,
    }
  )
);