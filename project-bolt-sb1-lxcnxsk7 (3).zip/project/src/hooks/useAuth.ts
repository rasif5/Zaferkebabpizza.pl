import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface AuthStore {
  isAuthenticated: boolean;
  user: {
    username: string;
    role: 'admin';
  } | null;
  login: (password: string) => boolean;
  logout: () => void;
}

const ADMIN_PASSWORD = 'admin123'; // In a real app, this would be stored securely

export const useAuth = create<AuthStore>()(
  persist(
    (set) => ({
      isAuthenticated: false,
      user: null,
      login: (password: string) => {
        const isValid = password === ADMIN_PASSWORD;
        if (isValid) {
          set({ 
            isAuthenticated: true,
            user: {
              username: 'admin',
              role: 'admin'
            }
          });
        }
        return isValid;
      },
      logout: () => {
        set({ 
          isAuthenticated: false,
          user: null
        });
      },
    }),
    {
      name: 'auth-storage',
    }
  )
);