import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';
import { CheckCircle2, Circle, Clock, Truck, ChefHat, Package, Banknote, Bell, MapPin } from 'lucide-react';
import { Order, OrderStatus, useOrderStore } from '../stores/orderStore';

interface OrderTrackingProps {
  order: Order;
}

const getStatusSteps = (type: 'delivery' | 'pickup') => {
  if (type === 'delivery') {
    return [
      { status: 'confirmed' as OrderStatus, icon: <CheckCircle2 className="w-6 h-6" />, label: 'Order Confirmed' },
      { status: 'preparing' as OrderStatus, icon: <ChefHat className="w-6 h-6" />, label: 'Preparing' },
      { status: 'ready_for_delivery' as OrderStatus, icon: <Package className="w-6 h-6" />, label: 'Ready for Delivery' },
      { status: 'out_for_delivery' as OrderStatus, icon: <Truck className="w-6 h-6" />, label: 'Out for Delivery' },
      { status: 'delivered' as OrderStatus, icon: <CheckCircle2 className="w-6 h-6" />, label: 'Delivered' },
    ];
  } else {
    return [
      { status: 'confirmed' as OrderStatus, icon: <CheckCircle2 className="w-6 h-6" />, label: 'Order Confirmed' },
      { status: 'preparing' as OrderStatus, icon: <ChefHat className="w-6 h-6" />, label: 'Preparing' },
      { status: 'ready_for_pickup' as OrderStatus, icon: <Package className="w-6 h-6" />, label: 'Ready for Pickup' },
      { status: 'picked_up' as OrderStatus, icon: <CheckCircle2 className="w-6 h-6" />, label: 'Picked Up' },
    ];
  }
};

const OrderTracking: React.FC<OrderTrackingProps> = ({ order }) => {
  const { markNotificationAsRead } = useOrderStore();
  const [showNotifications, setShowNotifications] = React.useState(false);
  const notifications = order.notifications || [];
  const unreadCount = notifications.filter(n => !n.isRead).length;
  const statusSteps = getStatusSteps(order.type);
  const currentStepIndex = statusSteps.findIndex((step) => step.status === order.status);

  const handleNotificationClick = (notificationId: string) => {
    markNotificationAsRead(order.id, notificationId);
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex justify-between items-start mb-6">
        <h2 className="text-2xl font-semibold">Order Status</h2>
        <div className="relative">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="relative p-2 rounded-full hover:bg-gray-100"
            onClick={() => setShowNotifications(!showNotifications)}
          >
            <Bell className="h-6 w-6 text-gray-600" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-600 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">
                {unreadCount}
              </span>
            )}
          </motion.button>

          <AnimatePresence>
            {showNotifications && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg z-50"
              >
                <div className="p-4">
                  <h3 className="text-lg font-semibold mb-3">Notifications</h3>
                  <div className="space-y-3 max-h-60 overflow-y-auto">
                    {notifications.length === 0 ? (
                      <p className="text-gray-500 text-center py-2">No notifications yet</p>
                    ) : (
                      notifications.map((notification) => (
                        <motion.div
                          key={notification.id}
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className={`p-3 rounded-lg ${
                            notification.isRead ? 'bg-gray-50' : 'bg-blue-50'
                          }`}
                          onClick={() => handleNotificationClick(notification.id)}
                        >
                          <p className="text-sm font-medium">{notification.message}</p>
                          <p className="text-xs text-gray-500 mt-1">
                            {format(new Date(notification.timestamp), 'h:mm a')}
                          </p>
                        </motion.div>
                      ))
                    )}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
      
      {/* Order ID and Time */}
      <div className="mb-6">
        <p className="text-gray-600">Order #{order.id}</p>
        <p className="text-gray-600">
          Placed on {format(new Date(order.timestamps.created), 'MMM d, yyyy h:mm a')}
        </p>
      </div>

      {/* Payment Info */}
      <div className="mb-6 p-4 bg-gray-50 rounded-lg">
        <div className="flex items-center mb-2">
          <Banknote className="w-5 h-5 mr-2 text-gray-600" />
          <h3 className="font-semibold">Payment Details</h3>
        </div>
        <div className="space-y-1 text-sm text-gray-600">
          <p>Payment Method: Cash</p>
          <p>Total Amount: {(order.total + (order.type === 'delivery' ? order.deliveryFee : 0)).toFixed(2)} zł</p>
          {order.changeNeeded && order.changeNeeded > 0 && (
            <p>Change to Prepare: {order.changeNeeded.toFixed(2)} zł</p>
          )}
        </div>
      </div>

      {/* Status Timeline */}
      <div className="relative">
        {statusSteps.map((step, index) => {
          const isCompleted = index <= currentStepIndex;
          const isCurrent = index === currentStepIndex;
          
          return (
            <div key={step.status} className="flex items-start mb-8 last:mb-0">
              {/* Status Icon */}
              <motion.div
                initial={false}
                animate={{
                  backgroundColor: isCompleted ? 'rgb(220 38 38)' : 'rgb(229 231 235)',
                  scale: isCurrent ? 1.2 : 1,
                }}
                className="rounded-full p-2 mr-4"
              >
                {isCompleted ? (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="text-white"
                  >
                    {step.icon}
                  </motion.div>
                ) : (
                  <Circle className="w-6 h-6 text-gray-400" />
                )}
              </motion.div>

              {/* Status Details */}
              <div className="flex-1">
                <h3 className="font-semibold">{step.label}</h3>
                {order.timestamps[step.status] && (
                  <p className="text-sm text-gray-500">
                    {format(new Date(order.timestamps[step.status]!), 'h:mm a')}
                  </p>
                )}
              </div>
            </div>
          );
        })}

        {/* Connecting Line */}
        <div className="absolute left-4 top-0 w-px h-full bg-gray-200 -z-10" />
      </div>

      {/* Delivery/Pickup Info */}
      {order.type === 'delivery' && order.status === 'out_for_delivery' && order.deliveryDriver && (
        <div className="mt-8 p-4 bg-gray-50 rounded-lg">
          <h3 className="font-semibold mb-2">Delivery Information</h3>
          <p className="text-gray-600">Driver: {order.deliveryDriver.name}</p>
          <p className="text-gray-600">Contact: {order.deliveryDriver.phone}</p>
          {order.deliveryDriver.vehicleInfo && (
            <p className="text-gray-600">Vehicle: {order.deliveryDriver.vehicleInfo}</p>
          )}
          {order.estimatedTime && (
            <div className="flex items-center mt-2 text-red-600">
              <Clock className="w-4 h-4 mr-2" />
              <span>Estimated delivery by {format(new Date(order.estimatedTime), 'h:mm a')}</span>
            </div>
          )}
        </div>
      )}

      {order.type === 'pickup' && (
        <div className="mt-8 p-4 bg-gray-50 rounded-lg">
          <h3 className="font-semibold mb-2">Pickup Information</h3>
          <div className="flex items-center text-gray-600 mb-2">
            <MapPin className="w-4 h-4 mr-2" />
            <p>ul. Rolna 63, Katowice</p>
          </div>
          {order.estimatedTime && (
            <div className="flex items-center text-red-600">
              <Clock className="w-4 h-4 mr-2" />
              <span>Ready for pickup by {format(new Date(order.estimatedTime), 'h:mm a')}</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default OrderTracking;