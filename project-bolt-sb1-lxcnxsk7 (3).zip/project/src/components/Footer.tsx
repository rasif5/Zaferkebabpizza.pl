import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Instagram, Phone, MapPin, Mail, MessageCircle, Clock } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Contact Information */}
          <div>
            <h3 className="text-xl font-semibold mb-4">Contact Us</h3>
            <div className="space-y-3">
              <div className="flex items-center">
                <Phone className="h-5 w-5 mr-2" />
                <a href="tel:512928003" className="hover:text-red-400">512 928 003</a>
              </div>
              <div className="flex items-center">
                <MapPin className="h-5 w-5 mr-2" />
                <p>ul. Rolna 63, Katowice</p>
              </div>
              <div className="flex items-center">
                <Mail className="h-5 w-5 mr-2" />
                <a href="mailto:contact@zaferkebab.pl" className="hover:text-red-400">
                  contact@zaferkebab.pl
                </a>
              </div>
              <div className="flex items-center">
                <MessageCircle className="h-5 w-5 mr-2" />
                <a 
                  href="https://wa.me/48512928003" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="hover:text-red-400"
                >
                  WhatsApp Chat
                </a>
              </div>
            </div>
          </div>

          {/* Opening Hours */}
          <div>
            <h3 className="text-xl font-semibold mb-4">Opening Hours</h3>
            <div className="space-y-2">
              <div className="flex items-center">
                <Clock className="h-5 w-5 mr-2" />
                <div>
                  <p>Monday - Thursday</p>
                  <p className="text-red-400">11:00 - 21:00</p>
                </div>
              </div>
              <div className="flex items-center">
                <Clock className="h-5 w-5 mr-2" />
                <div>
                  <p>Friday - Saturday</p>
                  <p className="text-red-400">11:00 - 22:00</p>
                </div>
              </div>
              <div className="flex items-center">
                <Clock className="h-5 w-5 mr-2" />
                <div>
                  <p>Sunday</p>
                  <p className="text-red-400">13:00 - 21:00</p>
                </div>
              </div>
            </div>
          </div>

          {/* Social Media */}
          <div>
            <h3 className="text-xl font-semibold mb-4">Follow Us</h3>
            <div className="flex space-x-4">
              <a href="https://facebook.com/zaferkebab" target="_blank" rel="noopener noreferrer" 
                className="hover:text-red-400">
                <Facebook className="h-6 w-6" />
              </a>
              <a href="https://instagram.com/zaferkebab" target="_blank" rel="noopener noreferrer"
                className="hover:text-red-400">
                <Instagram className="h-6 w-6" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center">
          <p className="text-sm text-gray-400">
            © {new Date().getFullYear()} Zafer Kebab & Pizza. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;