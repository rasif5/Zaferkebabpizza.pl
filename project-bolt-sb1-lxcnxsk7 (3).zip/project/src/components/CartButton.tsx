import React from 'react';
import { motion } from 'framer-motion';
import { ShoppingCart } from 'lucide-react';
import { useCart } from '../context/CartContext';

const CartButton = () => {
  const { state, dispatch } = useCart();
  const itemCount = state.items.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <motion.button
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.9 }}
      className="fixed bottom-8 right-8 bg-red-600 text-white p-4 rounded-full shadow-lg"
      onClick={() => dispatch({ type: 'TOGGLE_CART' })}
    >
      <div className="relative">
        <ShoppingCart size={24} />
        {itemCount > 0 && (
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="absolute -top-2 -right-2 bg-white text-red-600 rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold"
          >
            {itemCount}
          </motion.div>
        )}
      </div>
    </motion.button>
  );
};

export default CartButton;