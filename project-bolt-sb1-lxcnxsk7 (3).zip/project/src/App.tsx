import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import MenuPage from './pages/MenuPage';
import OrderPage from './pages/OrderPage';
import ReservationPage from './pages/ReservationPage';
import AdminPage from './pages/AdminPage';
import AdminLoginPage from './pages/AdminLoginPage';
import { CartProvider } from './context/CartContext';
import CartButton from './components/CartButton';
import AdminRoute from './components/AdminRoute';
import { useEffect } from 'react';
import { initializeCMS } from './utils/cms';

const queryClient = new QueryClient();

function App() {
  useEffect(() => {
    if (window.location.pathname.startsWith('/admin')) {
      // Load and initialize CMS
      const script = document.createElement('script');
      script.src = 'https://unpkg.com/decap-cms@^3.1.3/dist/decap-cms.js';
      script.async = true;
      script.onload = () => {
        initializeCMS();
      };
      document.body.appendChild(script);

      return () => {
        document.body.removeChild(script);
      };
    }
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <CartProvider>
          <div className="min-h-screen flex flex-col">
            <Routes>
              {/* Admin Routes */}
              <Route path="/admin/login" element={<AdminLoginPage />} />
              <Route
                path="/admin/*"
                element={
                  <AdminRoute>
                    <AdminPage />
                  </AdminRoute>
                }
              />
              
              {/* Public Routes */}
              <Route
                path="*"
                element={
                  <>
                    <Navbar />
                    <main className="flex-grow">
                      <Routes>
                        <Route path="/" element={<HomePage />} />
                        <Route path="/menu" element={<MenuPage />} />
                        <Route path="/order" element={<OrderPage />} />
                        <Route path="/reservations" element={<ReservationPage />} />
                      </Routes>
                    </main>
                    <CartButton />
                    <Footer />
                  </>
                }
              />
            </Routes>
          </div>
        </CartProvider>
      </Router>
    </QueryClientProvider>
  );
}

export default App