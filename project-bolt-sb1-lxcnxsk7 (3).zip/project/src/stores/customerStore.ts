import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface Customer {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  address?: string;
  loyaltyPoints: number;
  totalOrders: number;
  totalSpent: number;
  joinDate: string;
  lastOrderDate?: string;
  notes?: string;
  tags: string[];
  marketingConsent: boolean;
}

interface CustomerStore {
  customers: Customer[];
  addCustomer: (customer: Omit<Customer, 'id' | 'loyaltyPoints' | 'totalOrders' | 'totalSpent' | 'joinDate'>) => void;
  updateCustomer: (id: string, updates: Partial<Customer>) => void;
  deleteCustomer: (id: string) => void;
  addLoyaltyPoints: (id: string, points: number) => void;
  getCustomerById: (id: string) => Customer | undefined;
  searchCustomers: (query: string) => Customer[];
}

export const useCustomerStore = create<CustomerStore>()(
  persist(
    (set, get) => ({
      customers: [],
      addCustomer: (customerData) => {
        const newCustomer: Customer = {
          ...customerData,
          id: `CUST-${Date.now()}`,
          loyaltyPoints: 0,
          totalOrders: 0,
          totalSpent: 0,
          joinDate: new Date().toISOString(),
          tags: [],
        };
        set((state) => ({
          customers: [...state.customers, newCustomer],
        }));
      },
      updateCustomer: (id, updates) => {
        set((state) => ({
          customers: state.customers.map((customer) =>
            customer.id === id ? { ...customer, ...updates } : customer
          ),
        }));
      },
      deleteCustomer: (id) => {
        set((state) => ({
          customers: state.customers.filter((customer) => customer.id !== id),
        }));
      },
      addLoyaltyPoints: (id, points) => {
        set((state) => ({
          customers: state.customers.map((customer) =>
            customer.id === id
              ? { ...customer, loyaltyPoints: customer.loyaltyPoints + points }
              : customer
          ),
        }));
      },
      getCustomerById: (id) => {
        return get().customers.find((customer) => customer.id === id);
      },
      searchCustomers: (query) => {
        const searchTerm = query.toLowerCase();
        return get().customers.filter(
          (customer) =>
            customer.firstName.toLowerCase().includes(searchTerm) ||
            customer.lastName.toLowerCase().includes(searchTerm) ||
            customer.email.toLowerCase().includes(searchTerm) ||
            customer.phone.includes(searchTerm)
        );
      },
    }),
    {
      name: 'customer-storage',
    }
  )
);