import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface Promotion {
  id: string;
  code: string;
  title: string;
  description: string;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  startDate: string;
  endDate: string;
  active: boolean;
  minimumOrder?: number;
  maxUses?: number;
  currentUses: number;
  applicableItems?: string[];
}

interface PromotionStore {
  promotions: Promotion[];
  addPromotion: (promotion: Omit<Promotion, 'id' | 'currentUses'>) => void;
  updatePromotion: (id: string, updates: Partial<Promotion>) => void;
  deletePromotion: (id: string) => void;
  toggleActive: (id: string) => void;
  incrementUses: (id: string) => void;
  validatePromotion: (code: string, orderTotal: number) => Promotion | null;
}

export const usePromotionStore = create<PromotionStore>()(
  persist(
    (set, get) => ({
      promotions: [],
      addPromotion: (promotion) =>
        set((state) => ({
          promotions: [
            ...state.promotions,
            { ...promotion, id: `PROMO-${Date.now()}`, currentUses: 0 },
          ],
        })),
      updatePromotion: (id, updates) =>
        set((state) => ({
          promotions: state.promotions.map((promo) =>
            promo.id === id ? { ...promo, ...updates } : promo
          ),
        })),
      deletePromotion: (id) =>
        set((state) => ({
          promotions: state.promotions.filter((promo) => promo.id !== id),
        })),
      toggleActive: (id) =>
        set((state) => ({
          promotions: state.promotions.map((promo) =>
            promo.id === id ? { ...promo, active: !promo.active } : promo
          ),
        })),
      incrementUses: (id) =>
        set((state) => ({
          promotions: state.promotions.map((promo) =>
            promo.id === id
              ? { ...promo, currentUses: promo.currentUses + 1 }
              : promo
          ),
        })),
      validatePromotion: (code, orderTotal) => {
        const promotion = get().promotions.find(
          (p) =>
            p.code === code &&
            p.active &&
            new Date() >= new Date(p.startDate) &&
            new Date() <= new Date(p.endDate) &&
            (!p.maxUses || p.currentUses < p.maxUses) &&
            (!p.minimumOrder || orderTotal >= p.minimumOrder)
        );
        return promotion || null;
      },
    }),
    {
      name: 'promotion-storage',
    }
  )
);