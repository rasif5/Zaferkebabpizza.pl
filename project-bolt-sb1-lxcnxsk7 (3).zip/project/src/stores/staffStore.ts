import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type StaffRole = 'admin' | 'manager' | 'waiter' | 'chef' | 'delivery';

export interface StaffMember {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  role: StaffRole;
  active: boolean;
  hireDate: string;
  schedule: {
    [key: string]: {
      start: string;
      end: string;
    };
  };
  permissions: string[];
}

interface StaffStore {
  staff: StaffMember[];
  addStaffMember: (member: Omit<StaffMember, 'id'>) => void;
  updateStaffMember: (id: string, updates: Partial<StaffMember>) => void;
  deleteStaffMember: (id: string) => void;
  toggleStaffActive: (id: string) => void;
  updateSchedule: (id: string, day: string, start: string, end: string) => void;
  updatePermissions: (id: string, permissions: string[]) => void;
}

export const useStaffStore = create<StaffStore>()(
  persist(
    (set) => ({
      staff: [],
      addStaffMember: (member) =>
        set((state) => ({
          staff: [...state.staff, { ...member, id: `STAFF-${Date.now()}` }],
        })),
      updateStaffMember: (id, updates) =>
        set((state) => ({
          staff: state.staff.map((member) =>
            member.id === id ? { ...member, ...updates } : member
          ),
        })),
      deleteStaffMember: (id) =>
        set((state) => ({
          staff: state.staff.filter((member) => member.id !== id),
        })),
      toggleStaffActive: (id) =>
        set((state) => ({
          staff: state.staff.map((member) =>
            member.id === id ? { ...member, active: !member.active } : member
          ),
        })),
      updateSchedule: (id, day, start, end) =>
        set((state) => ({
          staff: state.staff.map((member) =>
            member.id === id
              ? {
                  ...member,
                  schedule: {
                    ...member.schedule,
                    [day]: { start, end },
                  },
                }
              : member
          ),
        })),
      updatePermissions: (id, permissions) =>
        set((state) => ({
          staff: state.staff.map((member) =>
            member.id === id ? { ...member, permissions } : member
          ),
        })),
    }),
    {
      name: 'staff-storage',
    }
  )
);