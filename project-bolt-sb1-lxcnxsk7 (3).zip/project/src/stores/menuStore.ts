import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface MenuItem {
  id: string;
  name: string;
  description?: string;
  price: string | string[];
  category: 'pizza' | 'kebab' | 'drinks' | 'extras';
  image?: string;
  available: boolean;
  outOfStock: boolean;
  outOfStockReason?: string;
  sizes?: string[];
}

// Initial menu data from the website
const initialMenuItems: MenuItem[] = [
  // Pizza Menu Items
  {
    id: 'margherita',
    name: 'MARGHERITA',
    description: 'sos pomidorowy, mozzarella',
    price: '30 zł',
    category: 'pizza',
    image: 'https://images.unsplash.com/photo-1574071318508-1cdbab80d002?auto=format&fit=crop&q=80&w=800',
    available: true,
    outOfStock: false
  },
  {
    id: 'fungi',
    name: 'FUNGI',
    description: 'Sos pomidorowy, mozzarella, pieczarki',
    price: '32 zł',
    category: 'pizza',
    image: 'https://images.unsplash.com/photo-1628840042765-356cda07504e?auto=format&fit=crop&q=80&w=800',
    available: true,
    outOfStock: false
  },
  {
    id: 'salami',
    name: 'SALAMI',
    description: 'sos pomidorowy, mozzarella, salami',
    price: '33 zł',
    category: 'pizza',
    image: 'https://images.unsplash.com/photo-1458642849426-cfb724f15ef7?auto=format&fit=crop&q=80&w=800',
    available: true,
    outOfStock: false
  },
  {
    id: 'prosciutto',
    name: 'PROSCIUTTO',
    description: 'Sos pomidorowy, mozzarella, szynka',
    price: '33 zł',
    category: 'pizza',
    image: 'https://images.unsplash.com/photo-1604068549290-dea0e4a305ca?auto=format&fit=crop&q=80&w=800',
    available: true,
    outOfStock: false
  },
  {
    id: 'prosciutto-fungi',
    name: 'PROSCIUTTO FUNGI',
    description: 'Sos pomidorowy, mozzarella, szynka, pieczarki',
    price: '35 zł',
    category: 'pizza',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800',
    available: true,
    outOfStock: false
  },
  {
    id: 'diavola',
    name: 'DIAVOLA',
    description: 'Sos pomidorowy, mozzarella, pieczarki, salami, jalapeno, peperoni',
    price: '45 zł',
    category: 'pizza',
    image: 'https://images.unsplash.com/photo-1458642849426-cfb724f15ef7?auto=format&fit=crop&q=80&w=800',
    available: true,
    outOfStock: false
  },
  {
    id: 'ciao-capperi',
    name: 'CIAO CAPPERI',
    description: 'Sos pomidorowy, mozzarella, pieczarki, oliwki, salami, cebula, kapary',
    price: '30 zł',
    category: 'pizza',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800',
    available: true,
    outOfStock: false
  },
  {
    id: 'hawaii',
    name: 'HAWAII',
    description: 'Sos pomidorowy, mozzarella, szynka, ananas',
    price: '36 zł',
    category: 'pizza',
    image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&q=80&w=800',
    available: true,
    outOfStock: false
  },
  {
    id: 'tonno',
    name: 'TONNO',
    description: 'Sos pomidorowy, mozzarella, tuńczyk, kapary, cebula, oliwki',
    price: '30 zł',
    category: 'pizza',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800',
    available: true,
    outOfStock: false
  },
  {
    id: 'carbonara',
    name: 'CARBONARA',
    description: 'Sos śmietanowy, mozzarella, boczek, jajko, ser brie, cebula, grana padano',
    price: '30 zł',
    category: 'pizza',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800',
    available: true,
    outOfStock: false
  },
  {
    id: 'ciao-italia',
    name: 'CIAO ITALIA',
    description: 'Sos, mozzarella, szynka parmeńska, rukola, cherry pomidory',
    price: '44 zł',
    category: 'pizza',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800',
    available: true,
    outOfStock: false
  },
  {
    id: 'quatro-formaggi',
    name: 'QUATRO FORMAGGI',
    description: 'Mozzarella, ser brie, gorgonzola, grana padano',
    price: '40 zł',
    category: 'pizza',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800',
    available: true,
    outOfStock: false
  },
  {
    id: 'chorizo',
    name: 'CHORIZO',
    description: 'Sos pomidorowy, mozzarella, cebula, jalapeno, chorizo, oliwki',
    price: '35 zł',
    category: 'pizza',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800',
    available: true,
    outOfStock: false
  },
  {
    id: 'carne',
    name: 'CARNE',
    description: 'Sos śmietanowy, mozzarella, boczek, szynka, salami, cebula',
    price: '41 zł',
    category: 'pizza',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800',
    available: true,
    outOfStock: false
  },
  {
    id: 'miele',
    name: 'MIELE',
    description: 'Sos pomidorowy, mozzarella, chorizo, jalapeno, rukola, miód',
    price: '45 zł',
    category: 'pizza',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800',
    available: true,
    outOfStock: false
  },
  {
    id: 'calzone',
    name: 'CALZONE',
    description: 'Sos pomidorowy, mozzarella, szynka, salami, pieczarki',
    price: '35 zł',
    category: 'pizza',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800',
    available: true,
    outOfStock: false
  },
  {
    id: 'kebab-pizza',
    name: 'KEBAB PIZZA',
    description: 'Sos pomidorowy, mozzarella, kebab wołowina, peperoni, cebula, cherry pomidory',
    price: '45 zł',
    category: 'pizza',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800',
    available: true,
    outOfStock: false
  },
  {
    id: 'bambino',
    name: 'BAMBINO',
    description: 'Sos pomidorowy, mozzarella',
    price: '25 zł',
    category: 'pizza',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800',
    available: true,
    outOfStock: false
  },
  {
    id: 'bella',
    name: 'BELLA',
    description: 'Sos pomidorowy, mozzarella, oliwki, szynka, grana padano',
    price: '39 zł',
    category: 'pizza',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800',
    available: true,
    outOfStock: false
  },
  {
    id: 'calzone-vegetariana',
    name: 'CALZONE VEGETARIANA',
    description: 'Sos pomidorowy, mozzarella, pieczarki, cebula, kukurydza, oliwki',
    price: '33 zł',
    category: 'pizza',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800',
    available: true,
    outOfStock: false
  },
  {
    id: 'vegetariana',
    name: 'VEGETARIANA',
    description: 'Sos pomidorowy, mozzarella, oliwki, cebula, pieczarki, kukurydza, rukola',
    price: '33 zł',
    category: 'pizza',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800',
    available: true,
    outOfStock: false
  },
  // Kebab Menu Items
  {
    id: 'kebab-w-ciescie',
    name: 'KEBAB W CIEŚCIE',
    description: 'mięso, surówki, sos',
    price: ['22 zł', '26 zł', '31 zł', '36 zł'],
    category: 'kebab',
    image: 'https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?auto=format&fit=crop&q=80&w=800',
    available: true,
    outOfStock: false,
    sizes: ['small', 'medium', 'large', 'mega']
  },
  {
    id: 'kebab-box',
    name: 'KEBAB KUBEŁEK',
    description: 'mięso, frytki, surówki, sos',
    price: ['22 zł', '26 zł', '32 zł'],
    category: 'kebab',
    image: 'https://images.unsplash.com/photo-1529006557810-274b9b2fc783?auto=format&fit=crop&q=80&w=800',
    available: true,
    outOfStock: false,
    sizes: ['small', 'medium', 'large']
  },
  // Drinks
  {
    id: 'pepsi',
    name: 'PEPSI',
    price: '8 zł',
    category: 'drinks',
    image: 'https://images.unsplash.com/photo-1553456558-aff63285bdd1?auto=format&fit=crop&q=80&w=800',
    available: true,
    outOfStock: false
  },
  // Extras
  {
    id: 'frytki',
    name: 'FRYTKI',
    price: ['10 zł', '15 zł'],
    category: 'extras',
    image: 'https://images.unsplash.com/photo-1630384060421-cb20d0e0649d?auto=format&fit=crop&q=80&w=800',
    available: true,
    outOfStock: false,
    sizes: ['small', 'large']
  }
];

interface MenuStore {
  items: MenuItem[];
  addItem: (item: Omit<MenuItem, 'id' | 'outOfStock' | 'outOfStockReason'>) => void;
  updateItem: (id: string, updates: Partial<MenuItem>) => void;
  deleteItem: (id: string) => void;
  loadFromCMS: () => Promise<void>;
}

export const useMenuStore = create<MenuStore>()(
  persist(
    (set) => ({
      items: initialMenuItems,
      addItem: (item) => set((state) => ({
        items: [...state.items, { 
          ...item, 
          id: `ITEM-${Date.now()}`,
          outOfStock: false
        }]
      })),
      updateItem: (id, updates) => set((state) => ({
        items: state.items.map((item) =>
          item.id === id ? { ...item, ...updates } : item
        )
      })),
      deleteItem: (id) => set((state) => ({
        items: state.items.filter((item) => item.id !== id)
      })),
      loadFromCMS: async () => {
        try {
          const response = await fetch('/api/menu');
          const data = await response.json();
          set({ items: data });
        } catch (error) {
          console.error('Failed to load menu from CMS:', error);
        }
      }
    }),
    {
      name: 'menu-storage',
    }
  )
);