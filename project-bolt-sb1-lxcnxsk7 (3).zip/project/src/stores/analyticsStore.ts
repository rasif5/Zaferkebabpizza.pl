import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface AnalyticsData {
  dailyRevenue: number[];
  monthlyRevenue: number[];
  popularItems: Array<{
    name: string;
    count: number;
    revenue: number;
  }>;
  customerSatisfaction: number;
  totalOrders: number;
  averageOrderValue: number;
  peakHours: Array<{
    hour: number;
    orders: number;
  }>;
}

interface AnalyticsStore {
  data: AnalyticsData;
  updateDailyRevenue: (amount: number) => void;
  updateMonthlyRevenue: (amount: number) => void;
  addPopularItem: (name: string, count: number, revenue: number) => void;
  updateCustomerSatisfaction: (rating: number) => void;
  incrementTotalOrders: () => void;
  updateAverageOrderValue: (amount: number) => void;
  addPeakHourData: (hour: number, orders: number) => void;
}

export const useAnalyticsStore = create<AnalyticsStore>()(
  persist(
    (set) => ({
      data: {
        dailyRevenue: Array(7).fill(0),
        monthlyRevenue: Array(12).fill(0),
        popularItems: [],
        customerSatisfaction: 0,
        totalOrders: 0,
        averageOrderValue: 0,
        peakHours: [],
      },
      updateDailyRevenue: (amount) =>
        set((state) => ({
          data: {
            ...state.data,
            dailyRevenue: [...state.data.dailyRevenue.slice(1), amount],
          },
        })),
      updateMonthlyRevenue: (amount) =>
        set((state) => ({
          data: {
            ...state.data,
            monthlyRevenue: [...state.data.monthlyRevenue.slice(1), amount],
          },
        })),
      addPopularItem: (name, count, revenue) =>
        set((state) => ({
          data: {
            ...state.data,
            popularItems: [...state.data.popularItems, { name, count, revenue }],
          },
        })),
      updateCustomerSatisfaction: (rating) =>
        set((state) => ({
          data: {
            ...state.data,
            customerSatisfaction: rating,
          },
        })),
      incrementTotalOrders: () =>
        set((state) => ({
          data: {
            ...state.data,
            totalOrders: state.data.totalOrders + 1,
          },
        })),
      updateAverageOrderValue: (amount) =>
        set((state) => ({
          data: {
            ...state.data,
            averageOrderValue:
              (state.data.averageOrderValue * state.data.totalOrders + amount) /
              (state.data.totalOrders + 1),
          },
        })),
      addPeakHourData: (hour, orders) =>
        set((state) => ({
          data: {
            ...state.data,
            peakHours: [...state.data.peakHours, { hour, orders }],
          },
        })),
    }),
    {
      name: 'analytics-storage',
    }
  )
);