import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface Review {
  id: string;
  customerId: string;
  orderId?: string;
  rating: number;
  comment: string;
  date: string;
  visible: boolean;
  reply?: {
    text: string;
    date: string;
    staffId: string;
  };
}

interface ReviewStore {
  reviews: Review[];
  addReview: (review: Omit<Review, 'id' | 'date' | 'visible'>) => void;
  updateReview: (id: string, updates: Partial<Review>) => void;
  deleteReview: (id: string) => void;
  toggleVisibility: (id: string) => void;
  addReply: (id: string, text: string, staffId: string) => void;
  getAverageRating: () => number;
}

export const useReviewStore = create<ReviewStore>()(
  persist(
    (set, get) => ({
      reviews: [],
      addReview: (review) =>
        set((state) => ({
          reviews: [
            ...state.reviews,
            {
              ...review,
              id: `REVIEW-${Date.now()}`,
              date: new Date().toISOString(),
              visible: true,
            },
          ],
        })),
      updateReview: (id, updates) =>
        set((state) => ({
          reviews: state.reviews.map((review) =>
            review.id === id ? { ...review, ...updates } : review
          ),
        })),
      deleteReview: (id) =>
        set((state) => ({
          reviews: state.reviews.filter((review) => review.id !== id),
        })),
      toggleVisibility: (id) =>
        set((state) => ({
          reviews: state.reviews.map((review) =>
            review.id === id ? { ...review, visible: !review.visible } : review
          ),
        })),
      addReply: (id, text, staffId) =>
        set((state) => ({
          reviews: state.reviews.map((review) =>
            review.id === id
              ? {
                  ...review,
                  reply: {
                    text,
                    date: new Date().toISOString(),
                    staffId,
                  },
                }
              : review
          ),
        })),
      getAverageRating: () => {
        const reviews = get().reviews;
        if (reviews.length === 0) return 0;
        const sum = reviews.reduce((acc, review) => acc + review.rating, 0);
        return sum / reviews.length;
      },
    }),
    {
      name: 'review-storage',
    }
  )
);