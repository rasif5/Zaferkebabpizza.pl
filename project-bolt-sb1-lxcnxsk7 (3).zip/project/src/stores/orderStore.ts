import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { sendSMS, sendEmail } from '../utils/notifications';

export type OrderStatus = 
  | 'pending'
  | 'confirmed'
  | 'preparing'
  | 'ready_for_pickup'
  | 'ready_for_delivery'
  | 'out_for_delivery'
  | 'picked_up'
  | 'delivered'
  | 'cancelled';

export type OrderType = 'delivery' | 'pickup';

export interface Reservation {
  id: string;
  customerInfo: {
    firstName: string;
    lastName: string;
    phone: string;
    email?: string;
  };
  date: string;
  time: string;
  numberOfGuests: number;
  specialRequests?: string;
  status: 'pending' | 'confirmed' | 'cancelled';
  createdAt: string;
}

export interface OrderNotification {
  id: string;
  orderId: string;
  message: string;
  timestamp: string;
  status: OrderStatus;
  isRead: boolean;
}

export interface Order {
  id: string;
  type: OrderType;
  items: Array<{
    id: string;
    name: string;
    quantity: number;
    price: string;
    size?: string;
  }>;
  status: OrderStatus;
  total: number;
  deliveryFee: number;
  paymentMethod: 'cash';
  changeNeeded?: number;
  customerInfo: {
    firstName: string;
    lastName: string;
    phone: string;
    email?: string;
    address?: string;
    postalCode?: string;
    city?: string;
    notes?: string;
  };
  timestamps: {
    created: string;
    confirmed?: string;
    preparing?: string;
    readyForPickup?: string;
    readyForDelivery?: string;
    outForDelivery?: string;
    pickedUp?: string;
    delivered?: string;
    cancelled?: string;
  };
  estimatedTime?: string;
  deliveryDriver?: {
    name: string;
    phone: string;
    vehicleInfo?: string;
  };
  notifications: OrderNotification[];
}

const getStatusMessage = (status: OrderStatus, type: OrderType): string => {
  switch (status) {
    case 'confirmed':
      return 'Your order has been confirmed and will be prepared shortly!';
    case 'preparing':
      return 'Our chefs are now preparing your delicious meal!';
    case 'ready_for_pickup':
      return 'Your order is ready for pickup at our restaurant!';
    case 'ready_for_delivery':
      return 'Your order is ready and waiting for a delivery driver!';
    case 'out_for_delivery':
      return 'Your order is on its way to you!';
    case 'picked_up':
      return 'Your order has been picked up. Enjoy your meal!';
    case 'delivered':
      return 'Your order has been delivered. Enjoy your meal!';
    case 'cancelled':
      return 'Your order has been cancelled.';
    default:
      return 'Your order status has been updated.';
  }
};

const sendNotifications = async (order: Order, status: OrderStatus) => {
  const message = getStatusMessage(status, order.type);
  
  // Send SMS notification
  if (order.customerInfo.phone) {
    await sendSMS(
      order.customerInfo.phone,
      `Zafer Kebab & Pizza: ${message}`
    );
  }

  // Send email notification if email is provided
  if (order.customerInfo.email) {
    const emailSubject = `Order Update - ${order.id}`;
    const emailText = `
Dear ${order.customerInfo.firstName},

${message}

${status === 'out_for_delivery' && order.deliveryDriver ? `
Your delivery driver details:
Name: ${order.deliveryDriver.name}
Phone: ${order.deliveryDriver.phone}
Vehicle: ${order.deliveryDriver.vehicleInfo}
` : ''}

${order.estimatedTime ? `
${order.type === 'delivery' ? 'Estimated delivery time' : 'Estimated pickup time'}: ${new Date(order.estimatedTime).toLocaleTimeString()}
` : ''}

Order Details:
Order #: ${order.id}
Total Amount: ${(order.total + (order.type === 'delivery' ? order.deliveryFee : 0)).toFixed(2)} zł

${order.type === 'pickup' ? `
Pickup Address:
Zafer Kebab & Pizza
ul. Rolna 63, Katowice
` : ''}

Thank you for choosing Zafer Kebab & Pizza!
    `;

    await sendEmail(order.customerInfo.email, emailSubject, emailText);
  }
};

interface OrderStore {
  orders: Order[];
  reservations: Reservation[];
  activeOrder?: Order;
  createOrder: (order: Omit<Order, 'id' | 'status' | 'timestamps' | 'paymentMethod' | 'notifications'>) => void;
  updateOrderStatus: (orderId: string, status: OrderStatus) => void;
  getOrder: (orderId: string) => Order | undefined;
  markNotificationAsRead: (orderId: string, notificationId: string) => void;
  getUnreadNotificationsCount: (orderId: string) => number;
  createReservation: (reservation: Omit<Reservation, 'id' | 'status' | 'createdAt'>) => void;
  updateReservationStatus: (reservationId: string, status: Reservation['status']) => void;
}

export const useOrderStore = create<OrderStore>()(
  persist(
    (set, get) => ({
      orders: [],
      reservations: [],
      createOrder: (orderData) => {
        const newOrder: Order = {
          ...orderData,
          id: `ORDER-${Date.now()}`,
          status: 'pending',
          paymentMethod: 'cash',
          timestamps: {
            created: new Date().toISOString(),
          },
          notifications: [],
        };

        // Set estimated time based on order type
        const estimatedTime = new Date();
        if (newOrder.type === 'delivery') {
          estimatedTime.setMinutes(estimatedTime.getMinutes() + Math.floor(Math.random() * 15) + 45);
        } else {
          estimatedTime.setMinutes(estimatedTime.getMinutes() + Math.floor(Math.random() * 10) + 20);
        }
        newOrder.estimatedTime = estimatedTime.toISOString();
        
        set((state) => ({
          orders: [...state.orders, newOrder],
          activeOrder: newOrder,
        }));
        
        // Simulate order flow with notifications
        setTimeout(() => get().updateOrderStatus(newOrder.id, 'confirmed'), 30000);
        setTimeout(() => get().updateOrderStatus(newOrder.id, 'preparing'), 60000);

        if (newOrder.type === 'delivery') {
          setTimeout(() => get().updateOrderStatus(newOrder.id, 'ready_for_delivery'), 180000);
          setTimeout(() => {
            const order = get().orders.find(o => o.id === newOrder.id);
            if (order) {
              order.deliveryDriver = {
                name: 'John Smith',
                phone: '+48 123 456 789',
                vehicleInfo: 'White Toyota Yaris KT 12345',
              };
            }
            get().updateOrderStatus(newOrder.id, 'out_for_delivery');
          }, 240000);
          setTimeout(() => get().updateOrderStatus(newOrder.id, 'delivered'), 360000);
        } else {
          setTimeout(() => get().updateOrderStatus(newOrder.id, 'ready_for_pickup'), 180000);
          setTimeout(() => get().updateOrderStatus(newOrder.id, 'picked_up'), 240000);
        }
      },
      updateOrderStatus: (orderId, status) => {
        set((state) => {
          const updatedOrders = state.orders.map((order) => {
            if (order.id === orderId) {
              const notification: OrderNotification = {
                id: `NOTIF-${Date.now()}`,
                orderId,
                message: getStatusMessage(status, order.type),
                timestamp: new Date().toISOString(),
                status,
                isRead: false,
              };

              const updatedOrder = {
                ...order,
                status,
                timestamps: {
                  ...order.timestamps,
                  [status]: new Date().toISOString(),
                },
                notifications: [...order.notifications, notification],
              };

              // Send notifications
              sendNotifications(updatedOrder, status);

              return updatedOrder;
            }
            return order;
          });

          return {
            orders: updatedOrders,
            activeOrder: updatedOrders.find(o => o.id === orderId),
          };
        });
      },
      getOrder: (orderId) => {
        return get().orders.find((order) => order.id === orderId);
      },
      markNotificationAsRead: (orderId, notificationId) => {
        set((state) => ({
          orders: state.orders.map((order) =>
            order.id === orderId
              ? {
                  ...order,
                  notifications: order.notifications.map((notif) =>
                    notif.id === notificationId
                      ? { ...notif, isRead: true }
                      : notif
                  ),
                }
              : order
          ),
        }));
      },
      getUnreadNotificationsCount: (orderId) => {
        const order = get().orders.find((o) => o.id === orderId);
        return order?.notifications.filter((n) => !n.isRead).length ?? 0;
      },
      createReservation: (reservationData) => {
        const newReservation: Reservation = {
          ...reservationData,
          id: `RES-${Date.now()}`,
          status: 'pending',
          createdAt: new Date().toISOString(),
        };

        set((state) => ({
          reservations: [...state.reservations, newReservation],
        }));
      },
      updateReservationStatus: (reservationId, status) => {
        set((state) => ({
          reservations: state.reservations.map((reservation) =>
            reservation.id === reservationId
              ? { ...reservation, status }
              : reservation
          ),
        }));
      },
    }),
    {
      name: 'order-storage',
    }
  )
);