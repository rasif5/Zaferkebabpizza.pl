/// <reference types="vite/client" />

interface Window {
  CMS: {
    registerPreviewStyle: (path: string) => void;
    registerPreviewTemplate: (name: string, component: any) => void;
    registerEventListener: (options: { name: string; handler: (args: any) => void }) => void;
    init: () => void;
  };
}