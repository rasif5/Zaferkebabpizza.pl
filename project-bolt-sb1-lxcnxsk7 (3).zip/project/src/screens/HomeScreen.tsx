import React from 'react';
import { View, Text, ScrollView, Image, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { ArrowRight, Star, Clock, MapPin, Phone } from 'lucide-react-native';
import Animated, { FadeInDown, FadeInUp } from 'react-native-reanimated';

const HomeScreen = () => {
  const navigation = useNavigation();

  return (
    <ScrollView className="flex-1 bg-white">
      {/* Hero Section */}
      <View className="h-96 relative">
        <Image
          source={{ uri: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=2070' }}
          className="absolute inset-0 w-full h-full"
          resizeMode="cover"
        />
        <View className="absolute inset-0 bg-black/50" />
        <View className="absolute inset-0 p-6 justify-center">
          <Animated.Text
            entering={FadeInDown.delay(200)}
            className="text-4xl font-bold text-white mb-4"
          >
            Najlepsze Smaki Pizzy i Kebaba
          </Animated.Text>
          <Animated.Text
            entering={FadeInDown.delay(400)}
            className="text-lg text-white mb-6"
          >
            Odkryj wyjątkowe połączenie tradycyjnej włoskiej pizzy i autentycznego tureckiego kebaba
          </Animated.Text>
          <Animated.View entering={FadeInDown.delay(600)}>
            <TouchableOpacity
              onPress={() => navigation.navigate('Menu')}
              className="bg-red-600 rounded-full py-4 px-6 flex-row items-center justify-center"
            >
              <Text className="text-white font-semibold text-lg mr-2">Zobacz Menu</Text>
              <ArrowRight size={20} color="white" />
            </TouchableOpacity>
          </Animated.View>
        </View>
      </View>

      {/* Features Section */}
      <View className="py-12 px-6">
        <Animated.Text
          entering={FadeInUp.delay(200)}
          className="text-2xl font-bold text-center mb-8"
        >
          Dlaczego My?
        </Animated.Text>
        <View className="space-y-6">
          {[
            { icon: Star, title: 'Najwyższa Jakość', desc: 'Świeże składniki i tradycyjne receptury' },
            { icon: Clock, title: 'Szybka Dostawa', desc: 'Dostarczamy w 45 minut lub mniej' },
            { icon: MapPin, title: 'Dogodna Lokalizacja', desc: 'W samym sercu Katowic' },
          ].map((item, index) => (
            <Animated.View
              key={index}
              entering={FadeInUp.delay(400 + index * 200)}
              className="bg-gray-50 p-6 rounded-xl"
            >
              <View className="flex-row items-center">
                <item.icon size={24} color="#dc2626" />
                <Text className="text-lg font-semibold ml-3">{item.title}</Text>
              </View>
              <Text className="text-gray-600 mt-2">{item.desc}</Text>
            </Animated.View>
          ))}
        </View>
      </View>

      {/* Contact Section */}
      <View className="bg-gray-50 py-12 px-6">
        <Animated.Text
          entering={FadeInUp}
          className="text-2xl font-bold text-center mb-8"
        >
          Kontakt
        </Animated.Text>
        <View className="space-y-4">
          <TouchableOpacity className="flex-row items-center">
            <Phone size={20} color="#dc2626" />
            <Text className="ml-3 text-lg">512 928 003</Text>
          </TouchableOpacity>
          <View className="flex-row items-center">
            <MapPin size={20} color="#dc2626" />
            <Text className="ml-3 text-lg">ul. Rolna 63, Katowice</Text>
          </View>
        </View>
      </View>
    </ScrollView>
  );
};

export default HomeScreen;