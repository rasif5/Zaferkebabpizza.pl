import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, Image } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { ShoppingBag } from 'lucide-react-native';
import { useCart } from '../context/CartContext';
import Animated, { FadeInDown } from 'react-native-reanimated';

const MenuScreen = () => {
  const [activeMenu, setActiveMenu] = useState('pizza');
  const { dispatch } = useCart();
  const navigation = useNavigation();

  const handleAddToCart = (item: any, size?: string) => {
    const price = Array.isArray(item.prices) 
      ? item.prices[size ? ['small', 'medium', 'large', 'mega'].indexOf(size) : 0]
      : item.price;

    const itemToAdd = {
      id: `${item.name}${size ? `-${size}` : ''}`,
      name: item.name,
      price,
      quantity: 1,
      size,
      image: item.image,
    };

    dispatch({
      type: 'ADD_ITEM',
      payload: itemToAdd,
    });

    navigation.navigate('Cart');
  };

  return (
    <View className="flex-1 bg-gray-50">
      {/* Menu Type Selector */}
      <View className="flex-row p-4 bg-white">
        <TouchableOpacity
          onPress={() => setActiveMenu('pizza')}
          className={`flex-1 py-3 rounded-full ${
            activeMenu === 'pizza' ? 'bg-red-600' : 'bg-gray-100'
          } items-center mx-2`}
        >
          <Text
            className={`font-semibold ${
              activeMenu === 'pizza' ? 'text-white' : 'text-gray-700'
            }`}
          >
            Pizza
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => setActiveMenu('kebab')}
          className={`flex-1 py-3 rounded-full ${
            activeMenu === 'kebab' ? 'bg-red-600' : 'bg-gray-100'
          } items-center mx-2`}
        >
          <Text
            className={`font-semibold ${
              activeMenu === 'kebab' ? 'text-white' : 'text-gray-700'
            }`}
          >
            Kebab
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView className="flex-1 p-4">
        {activeMenu === 'pizza' ? (
          // Pizza Menu
          <View className="space-y-4">
            {menuData.pizza.items.map((item, index) => (
              <Animated.View
                key={item.name}
                entering={FadeInDown.delay(index * 100)}
                className="bg-white rounded-xl overflow-hidden shadow-sm"
              >
                <Image
                  source={{ uri: item.image }}
                  className="w-full h-48"
                  resizeMode="cover"
                />
                <View className="p-4">
                  <Text className="text-lg font-semibold">{item.name}</Text>
                  <Text className="text-gray-600 text-sm mb-3">{item.description}</Text>
                  <View className="flex-row justify-between items-center">
                    <Text className="text-red-600 font-semibold">{item.price}</Text>
                    <TouchableOpacity
                      onPress={() => handleAddToCart(item)}
                      className="bg-red-600 py-2 px-4 rounded-full flex-row items-center"
                    >
                      <ShoppingBag size={18} color="white" />
                      <Text className="text-white ml-2">Add to Cart</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </Animated.View>
            ))}
          </View>
        ) : (
          // Kebab Menu
          <View className="space-y-6">
            {menuData.kebab.categories.map((category, categoryIndex) => (
              <View key={category.title} className="space-y-4">
                <Text className="text-xl font-bold">{category.title}</Text>
                {category.subtitle && (
                  <Text className="text-gray-600 text-sm">{category.subtitle}</Text>
                )}
                <View className="space-y-4">
                  {category.items.map((item, itemIndex) => (
                    <Animated.View
                      key={item.name}
                      entering={FadeInDown.delay((categoryIndex + itemIndex) * 100)}
                      className="bg-white rounded-xl p-4 shadow-sm"
                    >
                      {item.image && (
                        <Image
                          source={{ uri: item.image }}
                          className="w-full h-48 rounded-lg mb-4"
                          resizeMode="cover"
                        />
                      )}
                      <Text className="text-lg font-semibold">{item.name}</Text>
                      {item.description && (
                        <Text className="text-gray-600 text-sm mb-3">{item.description}</Text>
                      )}
                      <View className="flex-row flex-wrap gap-2">
                        {item.prices ? (
                          item.prices.map((price, priceIndex) => {
                            const sizes = ['small', 'medium', 'large', 'mega'];
                            return (
                              <TouchableOpacity
                                key={priceIndex}
                                onPress={() => handleAddToCart(item, sizes[priceIndex])}
                                className="bg-red-600 py-2 px-4 rounded-full flex-row items-center"
                              >
                                <ShoppingBag size={18} color="white" />
                                <Text className="text-white ml-2 capitalize">
                                  {sizes[priceIndex]} - {price}
                                </Text>
                              </TouchableOpacity>
                            );
                          })
                        ) : (
                          <TouchableOpacity
                            onPress={() => handleAddToCart(item)}
                            className="bg-red-600 py-2 px-4 rounded-full flex-row items-center"
                          >
                            <ShoppingBag size={18} color="white" />
                            <Text className="text-white ml-2">Add - {item.price}</Text>
                          </TouchableOpacity>
                        )}
                      </View>
                    </Animated.View>
                  ))}
                </View>
              </View>
            ))}
          </View>
        )}
      </ScrollView>
    </View>
  );
};

export default MenuScreen;