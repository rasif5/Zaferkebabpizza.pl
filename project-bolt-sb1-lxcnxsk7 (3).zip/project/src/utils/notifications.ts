// Mock implementation for frontend demo
export const sendSMS = async (to: string, message: string) => {
  console.log('Mock SMS sent:', { to, message });
};

export const sendEmail = async (to: string, subject: string, text: string) => {
  console.log('Mock email sent:', { to, subject, text });
};