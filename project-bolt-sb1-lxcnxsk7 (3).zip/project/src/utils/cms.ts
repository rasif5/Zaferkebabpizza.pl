import { useMenuStore } from '../stores/menuStore';
import { useOrderStore } from '../stores/orderStore';
import { useCustomerStore } from '../stores/customerStore';

export const initializeCMS = () => {
  if (typeof window !== 'undefined' && window.CMS) {
    // Register preview styles
    window.CMS.registerPreviewStyle('/src/index.css');

    // Register preview templates
    window.CMS.registerPreviewTemplate('menu', ({ entry }) => {
      const data = entry.get('data').toJS();
      return `
        <div class="p-4">
          <h1 class="text-2xl font-bold mb-2">${data.name}</h1>
          <p class="text-gray-600 mb-4">${data.description || ''}</p>
          <div class="flex items-center">
            <span class="font-semibold mr-2">Price:</span>
            <span>${Array.isArray(data.price) ? data.price.join(' / ') : data.price}</span>
          </div>
        </div>
      `;
    });

    // Register event handlers
    window.CMS.registerEventListener({
      name: 'preSave',
      handler: async ({ entry }) => {
        const collection = entry.get('collection');
        const data = entry.get('data').toJS();

        switch (collection) {
          case 'menu':
            useMenuStore.getState().addItem(data);
            break;
          case 'orders':
            useOrderStore.getState().createOrder(data);
            break;
          case 'customers':
            useCustomerStore.getState().addCustomer(data);
            break;
        }
      },
    });
  }
};