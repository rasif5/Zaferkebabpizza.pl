# Zafer Kebab & Pizza

A modern web application for Zafer Kebab & Pizza restaurant, built with React, TypeScript, and Tailwind CSS.

## Features

- 🍕 Online menu with real-time updates
- 🛒 Shopping cart functionality
- 📱 Responsive design
- 🌍 Multi-language support (English, Polish, Russian)
- 🔐 Admin panel for order and reservation management
- 💳 Secure payment processing

## Tech Stack

- React 18
- TypeScript
- Tailwind CSS
- Framer Motion
- React Query
- i18next
- Zustand
- Vite

## Getting Started

### Prerequisites

- Node.js 18 or higher
- npm 9 or higher

### Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/zafer-kebab.git
cd zafer-kebab
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

The application will be available at `http://localhost:3000`.

### Building for Production

```bash
npm run build
```

### Running Tests

```bash
npm test
```

## Project Structure

```
src/
├── components/     # Reusable UI components
├── context/       # React context providers
├── hooks/         # Custom React hooks
├── i18n/          # Internationalization files
├── pages/         # Page components
├── stores/        # Zustand stores
├── utils/         # Utility functions
└── types/         # TypeScript type definitions
```

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.